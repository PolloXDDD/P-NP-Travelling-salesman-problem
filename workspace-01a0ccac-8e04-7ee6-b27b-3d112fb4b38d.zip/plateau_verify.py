"""
plateau_verify.py -- (1) corre el descenso 2-opt con movimientos laterales sobre una
instancia criptografica y (2) intenta CERTIFICAR el tour con certify_tour.

Objetivo: comprobar si el ingrediente que falta (aceptar empates) no solo baja el coste
sino que encuentra un ciclo Hamiltoniano *certificable* (i.e. resuelve el SAT).

Uso: python3 plateau_verify.py <bits> <rondas> <pares> <segundos>
"""
import sys
import time

import numpy as np

from crypto_cnf import make_instance
from sat2tsp import reduce_cnf_to_tsp, certify_tour
from omega import tour_length, _nearest_neighbor_start_q2
from plateau_fast import deltas


def sideways_to_zero(D, tour, time_cap=300.0, seed=0, max_moves=200000):
    """Descenso 2-opt con laterales; se detiene en coste 0 o sin movimientos <=0."""
    import random
    rng = random.Random(seed)
    D = np.asarray(D, dtype=np.float64)
    t = np.array(tour, dtype=int)
    n = len(t)
    idx = np.arange(n)
    t0 = time.time()
    moves = 0
    while moves < max_moves and time.time() - t0 < time_cap:
        e = D[t, np.roll(t, -1)].sum()
        if e == 0.0:
            break
        d = deltas(D, t)
        mask = np.ones_like(d, dtype=bool)
        mask[idx, idx] = False
        mask[idx, (idx + 1) % n] = False
        mask[(idx + 1) % n, idx] = False
        d = np.where(mask, d, np.inf)
        best = d.min()
        if best < -1e-15:
            i, j = np.unravel_index(np.argmin(d), d.shape)
        else:
            cand = np.argwhere(d == 0.0)
            if len(cand) == 0:
                break
            i, j = cand[rng.randrange(len(cand))]
        if i > j:
            i, j = j, i
        t = np.concatenate([t[:i + 1], t[i + 1:j + 1][::-1], t[j + 1:]])
        moves += 1
    return t.tolist(), float(D[t, np.roll(t, -1)].sum()), moves, time.time() - t0


if __name__ == "__main__":
    bits = int(sys.argv[1]) if len(sys.argv) > 1 else 4
    rounds = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    npairs = int(sys.argv[3]) if len(sys.argv) > 3 else 1
    cap = float(sys.argv[4]) if len(sys.argv) > 4 else 300.0

    d = make_instance(bits, rounds, npairs, seed=1)
    inst = reduce_cnf_to_tsp(d["cnf"], name=f"spn{bits}b_r{rounds}_p{npairs}")
    start = _nearest_neighbor_start_q2(inst.D, 0)
    print(f"instancia n={inst.n} m={len(inst.edges)} | arranque NN={tour_length(inst.D, start):.0f}",
          flush=True)
    tour, cost, moves, dt = sideways_to_zero(inst.D, start, time_cap=cap)
    print(f"descenso con laterales: coste={cost:.0f} movs={moves} t={dt:.1f}s", flush=True)
    if cost == 0.0:
        ok, ass, motivo = certify_tour(inst, tour)
        print(f"certify_tour: ok={ok} motivo='{motivo}'", flush=True)
