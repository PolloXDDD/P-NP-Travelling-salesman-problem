# Evaluar `omega_q2_strict` vía reducción SAT→TSP con instancias criptográficas reducidas

*Informe de resultados. Fecha: 2026-09-23. Datos crudos en `results.jsonl`; export en `resultados.csv` y `escalado.png`.*

---

## 0. Resumen ejecutivo (lo esencial)

1. **La reducción funciona en el sentido constructivo** (testigo → tour de coste 0 → asignación
   verificada). En la familia criptográfica, todas las instancias SAT tienen un tour de coste 0
   **certificado** ("SAT certificado"), i.e. el óptimo del TSP es 0 (no hace falta resolutor exacto).
2. **Pero la reducción implementada NO es una decisión válida de SAT**: existen **ciclos de coste 0
   espurios** ("artefactos"). Demostrado por enumeración exhaustiva:
   - En modo `cracker`: una instancia **UNSAT** de 2 variables tiene **88 ciclos de coste 0**, todos
     espurios. En la de 1 variable, 8 ciclos de coste 0 de los que solo 2 son genuinos.
   - En modo `replace` los artefactos desaparecen con 1 variable pero **reaparecen con ≥2** (8/8
     espurios en la de 2 variables SAT) — es el bug de *crossover* ya identificado.
3. **Consecuencia para la evaluación del solver**: un coste 0 en el TSP **no implica SAT** con esta
   reducción. Hay que certificar (extraer asignación y verificarla contra la CNF). Los "aciertos" sin
   certificado no son evidencia.
4. **Resultado del solver** (criterio certificado):
   - CNFs diminutas (n_TSP = 15…128): `omega_q2_strict` **certifica 1 de 6** (la de n=15). Llega a
     coste 0 en n=33 y n=58 **pero esos tours son artefactos** (no certifican). A partir de n=77 el
     coste queda en 2–6, con gap creciente y tiempo ~n² (0.12 s → 17.9 s).
   - Escalera criptográfica (n_TSP = 748…4411): **ningún certificado, ningún coste ≤ 17**. Mejores:
     `strict` = 18 en n=748 (¡884.9 s!); `plus` = 79 en n=748, 156–160 en n≈1500, 306 en n=3093.
     `strict` en n=1559 **agota el tope de 1800 s sin dar tour**.
5. **Causa raíz del estancamiento del solver** (independiente de la reducción): los tres operadores
   de `omega.py` aceptan **solo mejoras estrictas** (`delta < -1e-15`). En un TSP 0/1 el paisaje es
   plano (la mayoría de movimientos tiene Δ=0) y la búsqueda se congela en pocos movimientos.
   Permitiendo empates (Δ≤0) con el **mismo** 2-opt y el mismo arranque:
   - las 6 instancias pequeñas llegan a coste 0 (115–432 movimientos en n=77/99/128);
   - n=748 llega a **coste 0 en 5179 movimientos / 70 s** (vs 18 en 885 s del solver estricto);
   - n=1495 baja a 9 en 240 s (vs 80 estricto).
   En n≥33 esos tours **no certifican** (son los artefactos de la reducción), pero como *optimización
   del TSP* sí alcanzan el óptimo.

---

## 1. La reducción (`sat2tsp.py`)

- Gadgets tipo Sipser/Williams: por variable un "diamante" con ranuras; cada nodo-cláusula se injerta
  como detour sobre la ranura de cada variable que aparece en la cláusula; el detour solo es usable
  si el patrón de recorrido (fase) del gadget usa esa arista ⇒ ligado al valor del literal.
- TSP 0/1: `D[u,v]=0` si la arista existe, `1` si no. (Coste 0 ⇒ ciclo Hamiltoniano.)
- Validado: construcción testigo→tour (378/378 y 300/300 en barridos previos; y en todas las CNFs
  criptográficas); codificación CNF de la S-box exacta (verificada sobre las 256 parejas y **sobre
  todas las claves** de los espacios de 4 y 8 bits: 0 discrepancias).

### 1.1 Prueba de insonoridad (enumeración exhaustiva de ciclos de coste 0)

`enumerate_zero_cycles.py` lista **todos** los ciclos Hamiltonianos de coste 0 de una instancia
diminuta y clasifica cada uno: *certificable* (la asignación de fases verifica la CNF) o *artefacto*.

| instancia | modo | ciclos de coste 0 | certificables | artefactos |
|---|---|---|---|---|
| 1 var, SAT | cracker | 8 | 2 | **6** |
| 1 var, UNSAT | cracker | 2 | 0 | **2** |
| 2 vars, SAT | cracker | 72 | 12 | **60** |
| 2 vars, UNSAT | cracker | **88** | 0 | **88** |
| 1 var, SAT | replace | 2 | 2 | 0 |
| 1 var, UNSAT | replace | 0 | 0 | 0 |
| 2 vars, SAT | replace | 8 | 0 | **8** |
| 2 vars, UNSAT | replace | 4 | 0 | **4** |

- `cracker`: insonoro ya desde 1 variable (las "patas" u–c–v y los puertos extra de entrada/salida
  crean rutas híbridas que no codifican ninguna asignación).
- `replace`: correcto con 1 variable; con 2 el patrón de crossover aparece (y además **desaparece el
  ciclo genuino** de la instancia SAT ⇒ incompleto, coherente con el fallo del constructor ya medido).
- Ejemplo del crossover (2 vars SAT, ciclo 0): el nodo `c1` (literal `x1 ∨ ¬x0`) usa los puertos
  `B1.1` (arista de la fase FALSA del gadget 1, que codifica `x1=VERDADERO`) y `T0.2`; la asignación
  leída es {x0=F, x1=V} y viola precisamente `c1`.

**Criterio de validación para el arreglo pendiente**: en estas instancias diminutas, el número de
artefactos debe ser **0** (y en UNSAT no debe haber ningún ciclo de coste 0). Es una prueba directa,
no estadística.

---

## 2. La familia criptográfica reducida (`crypto_cnf.py`)

SPN diminuto (estilo PRESENT): estado de 4–12 bits, 1–3 rondas, 1–2 pares texto/cifrado, tarea de
**recuperación de clave**. CNF por Tseitin (`xor2`/`xor_const` + S-box de 4 bits con 45 cláusulas).

| instancia | V | C | n_TSP | m_TSP | SAT |
|---|---|---|---|---|---|
| spn4b_r1_p1 | 12 | 57 | 748 | 1357 | sí |
| spn8b_r1_p1 | 24 | 114 | 1495 | 2713 | sí |
| spn4b_r2_p1 | 20 | 118 | 1559 | 2841 | sí |
| spn8b_r1_p2 | 40 | 228 | 2941 | 5345 | sí |
| spn4b_r2_p2 | 36 | 236 | 3093 | 5641 | sí |
| spn8b_r2_p1 | 40 | 236 | 3117 | 5681 | sí |
| spn8b_r2_p2_incons | 104 | ~636 | ~4200 | ~7800 | **no** (fuerza bruta de claves) |
| spn4b_r2_p2_incons | 60 | ~354 | ~4300 | — | **no** (idem) |
| spn12b_r1_p2 | 60 | 342 | 4411 | 8017 | sí |
| (spn8b_r3_p2) | 104 | 716 | ~9429 | — | excluida (D float64 ≈ 0.7 GB > memoria) |

Codificación verificada: para cada clave del espacio, la asignación canónica satisface la CNF ⇔ la
clave es consistente con todos los pares. Los UNSAT se certifican por fuerza bruta.

---

## 3. Banco de pruebas (`bench_tsp_sat.py`, `exp_ladder.py`, `results.jsonl`)

Por instancia: CNF → TSP → `omega_q2_plus` y `omega_q2_strict` con topes de tiempo; se registra
`n`, `m`, tiempo, coste, si alcanza el umbral (coste 0), **si certifica** (asignación verificada
contra la CNF) y el gap. El certificado es la única evidencia admisible de SAT.

## 4. Resultados

### 4.1 Curva por tamaño (CNFs aleatorias; óptimo = 0 probado por testigo)

| n_TSP | coste `plus` | t | coste `strict` | t | ¿coste 0? | ¿certificado? | gap strict |
|---|---|---|---|---|---|---|---|
| 15 | 1 | 0.0 s | **0** | 0.12 s | sí | **SÍ (SAT probado)** | 0 |
| 33 | 3 | 0.01 s | **0** | 0.73 s | sí | **no — artefacto** | 0* |
| 58 | 11 | 0.02 s | **0** | 3.06 s | sí | **no — artefacto** | 0* |
| 77 | 13 | 0.03 s | 2 | 5.46 s | no | — | 2 |
| 99 | 20 | 0.03 s | 3 | 10.56 s | no | — | 3 |
| 128 | 20 | 0.05 s | 6 | 17.85 s | no | — | 6 |

\* El coste 0 es del TSP (óptimo real), pero el ciclo no codifica una asignación satisfaciente ⇒
como test de SAT no cuenta.

### 4.2 Escalera criptográfica (SPN reducido) — resultados hasta ahora

| instancia | n_TSP | `plus` coste | t | `strict` coste | t | ¿umbral? | ¿certificado? |
|---|---|---|---|---|---|---|---|
| spn4b_r1_p1 | 748 | 79 | 2.9 s | 18 | 884.9 s | no | no (testigo sí: 0) |
| spn8b_r1_p1 | 1495 | 160 | 6.7 s | *(en curso)* | — | no | no |
| spn4b_r2_p1 | 1559 | 156 | 10.6 s | **timeout 1800 s** | — | no | no |
| spn4b_r2_p2 | 3093 | 306 | 29.2 s | (no se corre: n>1600) | — | no | no |

*(la escalera sigue corriendo en segundo plano; las filas restantes aparecerán en `results.jsonl`)*

Observaciones:
- El **testigo certifica el óptimo 0** en todas las SAT ⇒ el gap del solver es exacto y es enorme
  (76–306 en las corridas completas).
- `strict` es 100–300× más lento que `plus` y no mejora el coste en estas instancias.
- La reducción amplifica mucho el tamaño (n_TSP ≈ 8–13 × nº de cláusulas), así que la cifra más
  pequeña ya es un TSP de ~750 nodos.

### 4.3 Diagnóstico del estancamiento (`plateau_demo.py`, `plateau_fast.py`)

Mismo arranque (vecino más cercano) y mismos movimientos 2-opt; **solo** cambia el criterio de
aceptación (estricto Δ<0, como el solver, vs empates Δ≤0):

| instancia | n | arranque | estricto | con empates | movimientos hasta coste 0 |
|---|---|---|---|---|---|
| rand 15 | 15 | 5 | 4 (1 mov) | **0** | ≤3000 |
| rand 33 | 33 | 8 | 5 (3 mov) | **0** | ≤3000 |
| rand 58 | 58 | 17 | 11 (6 mov) | **0** | ≤3000 |
| rand 77 | 77 | 20 | 11 (9 mov) | **0** | 115 |
| rand 99 | 99 | 24 | 16 (8 mov) | **0** | 310 |
| rand 128 | 128 | 24 | 14 (10 mov) | **0** | 432 |
| spn4b_r1_p1 | 748 | 92 | 42 | **0** | 5179 (70 s) |
| spn8b_r1_p1 | 1495 | 173 | 80 | 9 | — (tope 240 s) |

El descenso estricto se detiene en 1–10 movimientos; aceptar empates llega al óptimo. En el TSP 0/1
el empate es señal útil (mueve el tour hacia otra estructura sin coste adicional).

---

## 5. Limitaciones y advertencias

1. **La reducción, tal cual, no decide SAT** (§1.1). Cualquier conclusión de "SAT alcanzado" exige
   certificado. Los números de "umbral" del solver en n=33/58 son artefactos del grafo, no aciertos.
2. `tour_to_assignment` (extractor estándar) falla en ciclos no canónicos; se añadió un extractor
   **robusto** por fases (`certify_robust.py`) que es **sound** (si la asignación de fases verifica la
   CNF, hay prueba) pero **incompleto** (si falla, no se concluye nada).
3. La escalera criptográfica tiene techo de memoria (~1 GB): n_TSP ≈ 9400 queda fuera.
4. `omega_q2_strict` no escala en estas instancias: 884.9 s para n=748 y timeout a 1800 s en n=1559.

## 6. Recomendaciones (por orden de impacto)

1. **Arreglar el crossover de la reducción** con el cableado clásico (fila con 3k+1 nodos internos,
   pares adyacentes por cláusula y **separador/buffer** entre pares; la cláusula que entra desde un
   nodo del par debe salir al compañero del mismo par). Validar con `enumerate_zero_cycles.py`:
   **0 artefactos** en las instancias diminutas, y 0 ciclos de coste 0 en UNSAT.
2. **Aceptar movimientos laterales (Δ≤0)** en los operadores del solver (con desempate aleatorio o
   tabú): es lo que separa "congelado en 18/42" de "coste 0" en esta familia. (Demostrado.)
3. **Arranques informados** en grafos dispersos: partir del grafo de coste 0 (path-cover/árbol) en vez
   de vecino más cercano sobre la matriz completa.
4. **Preprocesado**: contraer nodos forzados de grado 2 (`tsp_contract.py`, preserva el óptimo):
   −30 % de nodos en estas instancias.
5. Mientras la reducción no sea sound, usar el TSP solo como **banco de optimización** (los gaps de §4.2
   siguen siendo válidos como gaps de TSP) y **certificar** cualquier afirmación de SAT.

## 7. Ficheros

| fichero | contenido |
|---|---|
| `crypto_cnf.py` | familia criptográfica reducida (SPN) + verificación por fuerza bruta |
| `sat2tsp.py` | reducción CNF→TSP, `certify_tour`, oráculos (`has_hamiltonian_cycle`, `brute_sat`, …) |
| `certify_robust.py` | extractor robusto por fases + certificado sound |
| `enumerate_zero_cycles.py` | enumeración exhaustiva de ciclos de coste 0 y clasificación artefacto/genuino |
| `bench_tsp_sat.py` | banco de pruebas (una instancia / suite) con topes de tiempo |
| `exp_ladder.py` | driver: curva por tamaño y escalera criptográfica |
| `plateau_demo.py`, `plateau_fast.py`, `plateau_verify.py` | diagnóstico estricto vs empates |
| `tsp_contract.py` | contracción de nodos forzados (preserva óptimo) |
| `results.jsonl`, `resultados.csv`, `escalado.png` | resultados crudos y export |
| `validate_reduction.py`, `dbg*.py` | suites y depuración de la reducción |
