"""
certify_robust.py -- Extractor ROBUSTO de asignacion a partir de un ciclo de coste 0.

Motivacion: `tour_to_assignment` (en sat2tsp.py) exige que el ciclo siga el patron
"estandar" de los gadgets y devuelve None en cuanto hay una travesia no prevista
("estructura no estandar").  Pero para certificar SAT NO hace falta entender el ciclo:
basta DEFINIR
        x_i = verdadero  <=>  la arista (L_i, T_i.0) pertenece al ciclo
                            (y falso si la que aparece es (L_i, B_i.0))
y despues VERIFICAR la asignacion contra la CNF.  Si la satisface, SAT esta probado
(una asignacion que satisface la CNF es una prueba, independientemente de la forma del ciclo).

Si la verificacion falla, no se concluye nada: el ciclo puede ser un artefacto de la
reduccion (crossover) o una travesia no estandar.

Uso:
    from certify_robust import extract_assignment_by_phase, certify_robust
"""
from __future__ import annotations


def _edge_used(tour):
    n = len(tour)
    return set(tuple(sorted((tour[i], tour[(i + 1) % n]))) for i in range(n))


def extract_assignment_by_phase(inst, tour):
    """Devuelve (asignacion o None, motivo). asignacion: dict var_index -> bool (0-based)."""
    E = _edge_used(tour)
    assign = {}
    for g in inst.gadgets:
        t0 = tuple(sorted((g.L, g.T[0])))
        b0 = tuple(sorted((g.L, g.B[0])))
        if t0 in E:
            assign[g.var] = True
        elif b0 in E:
            assign[g.var] = False
        else:
            return None, f"gadget {g.var}: ni (L,T.0) ni (L,B.0) en el ciclo"
    return assign, "fases leidas de las entradas de gadget"


def certify_robust(inst, tour, expected_sat=True):
    """(ok, assign, motivo). ok=True <=> la asignacion extraida satisface la CNF."""
    from sat2tsp import check_tour_zero_cost
    info = check_tour_zero_cost(inst, tour)
    if not (info["permutation"] and info["cost"] == 0.0):
        return False, None, "tour no valido"
    assign, motivo = extract_assignment_by_phase(inst, tour)
    if assign is None:
        return False, None, motivo
    cnf = inst.cnf
    for j, cl in enumerate(cnf.clauses):
        if not any(assign.get(abs(lit) - 1, False) == (lit > 0) for lit in cl):
            return False, assign, f"la asignacion de fases NO satisface c{j}"
    return True, assign, "SAT certificado (asignacion de fases verifica la CNF)"
