"""
sat2tsp.py
==========
Reduccion  CNF-SAT  ->  TSP simetrico 0/1  (via CICLO HAMILTONIANO).

Idea
----
1) Reduccion clasica  CNF -> Grafo G  (gadgets "diamond" de Sipser/Wiliams):
     - nodos  s, t  y, por cada variable x_i, un gadget i
     - el gadget tiene tantas "ranuras" (slots) como clausulas contienen x_i
     - cada ranura r tiene un par de nodos de fila  (T_{i,r}, B_{i,r})
     - dentro del gadget el recorrido es ZIG-ZAG (Fase A) o ZAG-ZIG (Fase B);
       estas son las DOS UNICAS rutas Hamiltonianas  L_i -> R_i  del gadget.
       Fase A  ==  x_i = VERDADERO ,   Fase B  ==  x_i = FALSO.
     - Cada nodo-clausula c_j se "injerta" (detour) en la ranura r que la
       clausula j ocupa dentro del gadget de cada una de sus variables:
          literal positivo  x_i  ->  detour sobre la arista de fila usada en FASE A
          literal negativo ~x_i  ->  detour sobre la arista de fila usada en FASE B
       Por tanto el ciclo puede pasar por c_j SOLO a traves de una arista de
       ranura que su fase-gadget realmente recorre => solo si el literal es
       verdadero bajo la asignacion codificada por las fases.

2) Reduccion  Grafo -> TSP 0/1:  D[i][j] = 0 si (i,j) es arista de G, 1 si no.
   G tiene ciclo Hamiltoniano  <=>  existe tour de coste 0  (tour <= n).

RIGIDEZ (por que no hay "ciclos trampa"):
  (a) travesanos y conectores de cadena pasan por nodos de GRADO 2 -> son forzados.
  (b) cada gadget tiene una ranura DUMMY extra al final, de modo que TODOS los
      puertos de clausula caen en fronteras INTERIORES (entre ranura r y r+1)
      y NUNCA en las aristas de entrada (L-) ni de salida (-R).
  Con (a)+(b) el recorrido de cada gadget queda forzado a uno de los dos
  patrones zig-zag (FASE A / FASE B) con detours insertados; una travesia
  "parcial" (entrar/salir por un puerto) deja nodos de la propia columna
  sin grado disponible.  Ver validate_reduction.py para la evidencia.

Convencion de paridad (derivada de los dos patrones de recorrido):
   Sea r = 1..k_i el indice de ranura DENTRO del gadget.
   En FASE A (VERDADERO) el recorrido usa:
       arista INFERIOR (B_r - B_{r+1}) si r es impar
       arista SUPERIOR (T_r - T_{r+1}) si r es par
   (con la ranura k_i, "arista" = arista de salida B_{k_i}-R_i / T_{k_i}-R_i)
   En FASE B el recorrido usa exactamente la otra.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import itertools
import numpy as np


# ----------------------------------------------------------------------
# CNF
# ----------------------------------------------------------------------
@dataclass
class CNF:
    """nvars variables (1..nvars) y lista de clausulas de literales int (+v / -v)."""
    nvars: int
    clauses: list
    name: str = "cnf"

    def copy(self):
        return CNF(self.nvars, [tuple(c) for c in self.clauses], self.name)

    def stats(self):
        occ = sum(len(c) for c in self.clauses)
        lens = {}
        for c in self.clauses:
            lens[len(c)] = lens.get(len(c), 0) + 1
        return dict(nvars=self.nvars, nclauses=len(self.clauses), occurrences=occ, lens=lens)


def cnf_eval(cnf: CNF, assign: dict) -> bool:
    for cl in cnf.clauses:
        if not any((assign[v] if lit > 0 else not assign[v])
                   for lit in cl for v in [abs(lit) - 1]):
            return False
    return True


def preprocess_cnf(cnf: CNF, drop_tautologies=True, compact=True):
    """Deduplica literales, quita tautologias (x or ~x) y renumera variables."""
    clauses = []
    taut = 0
    for cl in cnf.clauses:
        lits = []
        seen = set()
        ok = True
        for lit in cl:
            if -lit in seen and drop_tautologies:
                ok = False
                break
            if lit in seen:
                continue
            seen.add(lit)
            lits.append(lit)
        if not ok:
            taut += 1
            continue
        clauses.append(tuple(lits))
    nv = cnf.nvars
    out = CNF(nv, clauses, cnf.name)
    if compact:
        used = sorted({abs(l) for cl in clauses for l in cl})
        if used != list(range(1, nv + 1)):
            remap = {v: k + 1 for k, v in enumerate(used)}
            out = CNF(len(used), [tuple((1 if l > 0 else -1) * remap[abs(l)] for l in cl)
                                  for cl in clauses], cnf.name)
    out.meta_tautologies = taut
    return out


# ----------------------------------------------------------------------
# Reduccion
# ----------------------------------------------------------------------
@dataclass
class Gadget:
    var: int          # 0-based (variable compactada)
    L: int
    R: int
    T: list = field(default_factory=list)   # nodos fila superior por ranura
    B: list = field(default_factory=list)   # nodos fila inferior por ranura
    Rg: list = field(default_factory=list)  # nodo de travesano por ranura (grado 2)
    clause_of_slot: list = field(default_factory=list)  # indice de clausula (0-based)
    nslots_index: dict = field(default_factory=dict)    # clausula -> indice de ranura


@dataclass
class TSPInstance:
    D: np.ndarray
    edges: list
    cnf: CNF                 # CNF preprocesada a la que corresponde la instancia
    gadgets: list
    clause_node: list
    s: int
    t: int
    labels: list
    name: str = "sat2tsp"
    port_mode: str = "cracker"

    # ---- utilidades ----
    @property
    def n(self):
        return self.D.shape[0]

    @property
    def m(self):
        return len(self.edges)

    def edge_set(self):
        return set(map(tuple, (tuple(sorted(e)) for e in self.edges)))

    def is_hamiltonian_tour(self, tour):
        n = self.n
        if len(tour) != n or sorted(tour) != list(range(n)):
            return False
        E = self.edge_set()
        for i in range(n):
            a, b = tour[i], tour[(i + 1) % n]
            if a == b:
                return False
            if (min(a, b), max(a, b)) not in E:
                return False
        return True

    def stats(self):
        s = self.cnf.stats()
        return dict(name=self.name, n_tsp=self.n, m_edges=self.m,
                    density=self.m / (self.n * (self.n - 1) / 2),
                    nvars=s["nvars"], nclauses=s["nclauses"],
                    occurrences=s["occurrences"], lens=s["lens"])


def reduce_cnf_to_tsp(cnf_in: CNF, name=None, preprocess=True, port_mode="cracker"):
    """
    CNF  ->  TSP simetrico 0/1.
    Devuelve un TSPInstance (D con 0 en aristas del grafo, 1 en no-aristas).
    """
    cnf = preprocess_cnf(cnf_in) if preprocess else cnf_in
    k = len(cnf.clauses)
    l = cnf.nvars

    # ranuras: por variable, la lista ordenada de clausulas que la contienen
    slots = [[] for _ in range(l)]
    for j, cl in enumerate(cnf.clauses):
        for lit in cl:
            slots[abs(lit) - 1].append(j)
    for i in range(l):
        slots[i] = sorted(set(slots[i]))

    # --- numeracion de nodos ---
    nid = 0
    s = nid; nid += 1
    t = nid; nid += 1
    labels = ["s", "t"]
    L = []; R = []
    for i in range(l):
        L.append(nid); labels.append(f"L{i}"); nid += 1
        R.append(nid); labels.append(f"R{i}"); nid += 1
    gadgets = []
    for i in range(l):
        g = Gadget(var=i, L=L[i], R=R[i])
        nreal = len(slots[i])
        for r in range(nreal + 1):          # +1 ranura DUMMY al final
            j = slots[i][r] if r < nreal else -1
            g.T.append(nid); labels.append(f"T{i}.{r}"); nid += 1
            g.B.append(nid); labels.append(f"B{i}.{r}"); nid += 1
            g.Rg.append(nid); labels.append(f"r{i}.{r}"); nid += 1   # travesano (grado 2 -> forzado)
            g.clause_of_slot.append(j)
            if j >= 0:
                g.nslots_index[j] = r
        gadgets.append(g)
    # connectores de cadena (grado 2)
    chain_mid = []
    if l > 0:
        for i in range(l - 1):
            chain_mid.append(nid); labels.append(f"x{i}"); nid += 1
    clause_node = []
    for j in range(k):
        clause_node.append(nid); labels.append(f"c{j}"); nid += 1
    n = nid

    E = set()
    def add(u, v):
        E.add((min(u, v), max(u, v)))

    # cadena global s -> ... -> t -> s  (con nodos intermedios de grado 2 => forzada)
    add(s, t)
    if l > 0:
        add(s, L[0])
        add(R[l - 1], t)
        for i in range(l - 1):
            add(R[i], chain_mid[i]); add(chain_mid[i], L[i + 1])
    for i, g in enumerate(gadgets):
        if len(g.T) == 0:
            add(g.L, g.R)          # variable que no aparece en ninguna clausula
            continue
        add(g.L, g.T[0]); add(g.L, g.B[0])
        for r in range(len(g.T)):
            add(g.T[r], g.Rg[r])                      # travesano forzado (grado 2)
            add(g.Rg[r], g.B[r])
        for r in range(len(g.T) - 1):
            add(g.T[r], g.T[r + 1])                   # fila superior
            add(g.B[r], g.B[r + 1])                   # fila inferior
        add(g.T[-1], g.R); add(g.B[-1], g.R)          # salida

    # --- detours de clausulas ---
    #  FASE A (x_i = V): en la ranura r0 usa la fila INFERIOR si r0 par, SUPERIOR si r0 impar.
    #  FASE B (x_i = F): al reves.
    #  port_mode="cracker": ANADE las patas (la arista de fila directa sigue existiendo).
    #      patas por ocurrencia: (fila(r0), fila(r0+1)) + entrada (L, otra_fila[0]) si r0==0
    #      + salida (fila[K-1], R) si r0==K-1.   Todas las patas son aristas de ESA fase.
    #  port_mode="replace": elimina la arista de fila elegida y la sustituye por el puerto.
    for j, cl in enumerate(cnf.clauses):
        for lit in cl:
            i = abs(lit) - 1
            g = gadgets[i]
            r0 = g.nslots_index[j]        # 0-based
            K = len(g.T)
            phase_A = lit > 0
            row_bottom = ((r0 % 2 == 0) == phase_A)
            Rrow = g.B if row_bottom else g.T
            Orow = g.T if row_bottom else g.B
            if port_mode == "cracker":
                legs = []
                if r0 <= K - 2:
                    legs.append((Rrow[r0], Rrow[r0 + 1]))
                if r0 == 0:
                    legs.append((g.L, Orow[0]))
                if r0 == K - 1:
                    legs.append((Rrow[K - 1], g.R))
                for u, v in legs:
                    add(u, clause_node[j]); add(clause_node[j], v)
            else:
                r = r0 + 1
                top_is_A = (r % 2 == 0)
                top_edge = (g.T[r0], g.T[r0 + 1])
                bot_edge = (g.B[r0], g.B[r0 + 1])
                edge_A = top_edge if top_is_A else bot_edge
                edge_B = bot_edge if top_is_A else top_edge
                chosen = edge_A if lit > 0 else edge_B
                u, v = chosen
                E.discard((min(u, v), max(u, v)))
                add(u, clause_node[j]); add(clause_node[j], v)

    # --- matriz 0/1 ---
    D = np.ones((n, n), dtype=np.float64)
    np.fill_diagonal(D, 0.0)
    for u, v in E:
        D[u, v] = 0.0
        D[v, u] = 0.0

    return TSPInstance(D=D, edges=sorted(E), cnf=cnf, gadgets=gadgets,
                       clause_node=clause_node, s=s, t=t, labels=labels,
                       name=name or cnf.name, port_mode=port_mode)


# ----------------------------------------------------------------------
# Extraccion / verificacion de asignacion desde un tour de coste 0
# ----------------------------------------------------------------------
def tour_to_assignment(inst: TSPInstance, tour):
    """
    Dado un tour de coste 0 (ciclo Hamiltoniano del grafo), lee la fase de cada
    gadget y devuelve {var0based: bool}.  Devuelve None si el tour no tiene la
    estructura estandar (no deberia pasar si el tour es Hamiltoniano valido).
    """
    n = inst.n
    # conjunto de aristas usadas por el tour (no depende de la orientacion del ciclo)
    used = set()
    for i in range(n):
        a, b = tour[i], tour[(i + 1) % n]
        used.add((min(a, b), max(a, b)))
    assign = {}
    for i, g in enumerate(inst.gadgets):
        if len(g.T) == 0:
            assign[i] = True
            continue
        # FASE A (VERDADERO) usa L-T0 ; FASE B (FALSO) usa L-B0
        if (min(g.L, g.T[0]), max(g.L, g.T[0])) in used:
            assign[i] = True
        elif (min(g.L, g.B[0]), max(g.L, g.B[0])) in used:
            assign[i] = False
        else:
            return None
    return assign


def check_tour_zero_cost(inst: TSPInstance, tour, verbose=False):
    """Verifica: (a) tour valido, (b) coste 0, (c) asignacion extraida satisface la CNF."""
    ok_perm = (len(tour) == inst.n and sorted(tour) == list(range(inst.n)))
    cost = sum(inst.D[tour[i], tour[(i + 1) % inst.n]] for i in range(inst.n))
    info = dict(permutation=ok_perm, cost=float(cost))
    assign = tour_to_assignment(inst, tour) if ok_perm else None
    info["assignment_extracted"] = assign is not None
    if assign is not None:
        info["assignment_satisfies_cnf"] = cnf_eval(inst.cnf, assign)
    return info


# ----------------------------------------------------------------------
# Verificacion estructural del gadget:  exactamente 2 rutas  L -> R
# ----------------------------------------------------------------------
def gadget_hamiltonian_path_count(k, use_detour_slots=(), rung_nodes=True, limit=5):
    """
    Cuenta rutas Hamiltonianas L->R del gadget con k ranuras (DFS con tope `limit`).

    rung_nodes=True  -> travesano como camino T - r - B con nodo intermedio de grado 2
                        (¡esto es lo que fuerza la estructura zig-zag!)
    rung_nodes=False -> arista directa T-B (variante INSEGURA: admite "serpientes"
                        que recorren filas completas sin usar travesanos)

    use_detour_slots: ranuras (1-based) donde se cuelga un nodo-detour de clausula.
       signo +  -> colgado de la arista de FASE A (literal VERDADERO)
       signo -  -> colgado de la arista de FASE B (literal FALSO)
    """
    nodes = ["L", "R"]
    for r in range(k):
        nodes += [f"T{r}", f"B{r}"]
        if rung_nodes:
            nodes += [f"g{r}"]
    for r in use_detour_slots:
        nodes.append(f"c{abs(r)}")
    idx = {nm: i for i, nm in enumerate(nodes)}
    n = len(nodes)
    adj = [set() for _ in range(n)]
    def e(a, b):
        adj[idx[a]].add(idx[b]); adj[idx[b]].add(idx[a])
    if k == 0:
        e("L", "R")
    else:
        e("L", "T0"); e("L", "B0")
        for r in range(k):
            if rung_nodes:
                e(f"T{r}", f"g{r}"); e(f"g{r}", f"B{r}")
            else:
                e(f"T{r}", f"B{r}")
        for r in range(k - 1):
            e(f"T{r}", f"T{r+1}"); e(f"B{r}", f"B{r+1}")
        e(f"T{k-1}", "R"); e(f"B{k-1}", "R")
        for rsign in use_detour_slots:
            r = abs(rsign); r0 = r - 1
            top_is_A = (r % 2 == 0)
            if r < k:
                top = (f"T{r0}", f"T{r0+1}"); bot = (f"B{r0}", f"B{r0+1}")
            else:
                top = (f"T{r0}", "R"); bot = (f"B{r0}", "R")
            edge_A = top if top_is_A else bot
            edge_B = bot if top_is_A else top
            a, b = edge_A if rsign > 0 else edge_B
            e(a, f"c{r}"); e(f"c{r}", b)
    src, dst = idx["L"], idx["R"]
    full = (1 << n) - 1
    count = [0]
    used0 = 1 << src

    def dfs(cur, used, depth):
        if count[0] >= limit:
            return
        if depth == n:
            if cur == dst:
                count[0] += 1
            return
        for nxt in sorted(adj[cur]):
            if not (used >> nxt) & 1:
                dfs(nxt, used | (1 << nxt), depth + 1)
                if count[0] >= limit:
                    return
    dfs(src, used0, 1)
    return count[0]


# ----------------------------------------------------------------------
# Oráculos independientes (para validar la reduccion)
# ----------------------------------------------------------------------
def brute_sat(cnf: CNF, max_vars=24):
    """Fuerza bruta sobre 2^nvars. Devuelve (sat?, asignacion o None)."""
    if cnf.nvars > max_vars:
        raise ValueError("demasiadas variables para fuerza bruta")
    for bits in itertools.product([False, True], repeat=cnf.nvars):
        a = {i: b for i, b in enumerate(bits)}
        if cnf_eval(cnf, a):
            return True, a
    return False, None


def has_hamiltonian_cycle(n, edges, budget=20_000_000):
    """
    Buscador exacto de ciclo Hamiltoniano (DFS + propagacion de grado 2).
    Devuelve (True/False/None, tour)  (None = presupuesto agotado).
    """
    adjm = [0] * n
    for u, v in edges:
        if u != v:
            adjm[u] |= 1 << v
            adjm[v] |= 1 << u
    for u in range(n):
        if bin(adjm[u]).count("1") < 2:
            return False, None
    steps = [0]
    full = (1 << n) - 1

    # vecinos forzados (grado 2 exacto tras quitar imposibles) -> propagacion
    def forced_mask(u):
        return adjm[u] if bin(adjm[u]).count("1") == 2 else 0

    path = [0]
    used = 1
    succ_of = {}

    import sys
    sys.setrecursionlimit(10000)

    def dfs(cur, used, depth):
        steps[0] += 1
        if steps[0] > budget:
            raise TimeoutError
        if depth == n:
            return bool(adjm[cur] & 1)
        # poda: todo nodo no visitado necesita >=2 enlaces disponibles
        rest = full & ~used
        cand = rest
        while cand:
            b = cand & -cand
            u = b.bit_length() - 1
            cand ^= b
            avail = bin(adjm[u] & (rest | (1 << cur) | 1)).count("1")
            if avail < 2:
                return False
        fm = forced_mask(cur)
        nxts = adjm[cur] & rest
        if fm:
            nxts &= fm
        # orden heuristico: menos opciones primero
        opts = []
        while nxts:
            b = nxts & -nxts
            u = b.bit_length() - 1
            nxts ^= b
            opts.append((bin(adjm[u] & rest).count("1"), u))
        opts.sort()
        for _, u in opts:
            succ_of[cur] = u
            if dfs(u, used | (1 << u), depth + 1):
                return True
            succ_of.pop(cur, None)
        return False

    try:
        if dfs(0, used, 1):
            tour = [0]
            for _ in range(n - 1):
                tour.append(succ_of[tour[-1]])
            return True, tour
        return False, None
    except TimeoutError:
        return None, None


def tsp_exact_cpsat(D, time_limit=30.0, num_workers=2, log=False):
    """Optimo exacto del TSP (CP-SAT, circuito Hamiltoniano). (valor, optimo_probado)."""
    from ortools.sat.python import cp_model
    D = np.asarray(D, dtype=np.float64)
    n = D.shape[0]
    model = cp_model.CpModel()
    arcs = {}
    for i in range(n):
        for j in range(n):
            if i != j:
                arcs[(i, j)] = model.NewBoolVar(f"x{i}_{j}")
    model.AddCircuit([(i, j, arcs[(i, j)]) for (i, j) in arcs])
    model.Minimize(sum(int(round(D[i, j])) * arcs[(i, j)] for (i, j) in arcs))
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = time_limit
    solver.parameters.num_search_workers = num_workers
    if log:
        solver.parameters.log_search_progress = True
    st = solver.Solve(model)
    if st == cp_model.OPTIMAL:
        return solver.ObjectiveValue(), True
    if st == cp_model.FEASIBLE:
        return solver.ObjectiveValue(), False
    return None, False


# ----------------------------------------------------------------------
# COMPLETITUD CONSTRUCTIVA:  asignacion satisfactoria  ->  tour de coste 0
# ----------------------------------------------------------------------
def assignment_to_tour(inst: TSPInstance, assign: dict):
    """
    Construye EXPLICITAMENTE un ciclo Hamiltoniano (coste 0) a partir de una
    asignacion satisfactoria.  =>  opt(TSP) <= 0;  como D >= 0:  opt(TSP) = 0.
    (Cota CERTIFICADA de completitud para toda CNF satisfacible.)

    Recorrido del gadget (indices r0 = 0..K-1, K = ranuras reales + dummy):
        L -> O[0] -> Rg[0] -> R[0] -> (c_j?) -> R[1] -> Rg[1] -> O[1] -> ... -> R
    donde la "fila usada" R(r0) = B si (FASE A y r0 par) o (FASE B y r0 impar),
    si no T;  O(r0) es la otra fila.  La clausula c_j se intercala en la arista
    de fila del slot r0 unicamente si esa arista es la que la fase usa
    (literal verdadero) y c_j aun no ha sido atendida.
    """
    G = inst.gadgets
    l = len(G)
    if l == 0:
        return [inst.s, inst.t]

    insert = {}                       # (gadget i, slot r0) -> nodo de clausula
    for j, cl in enumerate(inst.cnf.clauses):
        for lit in cl:
            if assign[abs(lit) - 1] == (lit > 0):
                i = abs(lit) - 1
                insert[(i, G[i].nslots_index[j])] = inst.clause_node[j]
                break
        else:
            return None               # clausula sin literal verdadero

    xnodes = [v for v, lab in enumerate(inst.labels) if lab.startswith("x")]
    tour = [inst.s]
    for i, g in enumerate(G):
        K = len(g.T)
        bottom = bool(assign[i])      # FASE A => fila usada en slot 0 = inferior
        tour.append(g.L)
        # nodo de entrada al travesano 0 (la otra fila, en el indice 0)
        tour.append(g.T[0] if bottom else g.B[0])   # entrada: la OTRA fila
        for r0 in range(K):
            R_ = g.B if bottom else g.T    # fila usada en este slot
            tour.append(g.Rg[r0])          # travesano
            tour.append(R_[r0])
            if r0 < K - 1:
                c = insert.get((i, r0))
                if c is not None:
                    tour.append(c)         # puerto: nodo de clausula
                tour.append(R_[r0 + 1])    # arista de fila (frontera r0 -> r0+1)
            else:
                tour.append(g.R)           # salida
            bottom = not bottom
        if i < l - 1:
            tour.append(xnodes[i])         # conector de cadena R_i - x_i - L_{i+1}
    tour.append(inst.t)

    if len(tour) != inst.n or len(set(tour)) != inst.n:
        return None
    E = inst.edge_set()
    for a_ in range(len(tour)):
        u, v = tour[a_], tour[(a_ + 1) % len(tour)]
        if (min(u, v), max(u, v)) not in E:
            return None
    return tour




# ----------------------------------------------------------------------
# CERTIFICACION: un tour de coste 0 -> asignacion satisfactoria (o None)
# ----------------------------------------------------------------------
def certify_tour(inst: TSPInstance, tour):
    """
    Devuelve (ok, assign, motivo):
      ok=True  => el tour es un ciclo Hamiltoniano y la asignacion extraida
                  satisface TODAS las clausulas  (=> el optimo del TSP es 0 y SAT=TRUE)
      ok=False => el tour es valido como ciclo pero NO certifica SAT (artefacto
                  de la reduccion) o el tour no es valido.
    """
    info = check_tour_zero_cost(inst, tour)
    if not (info["permutation"] and info["cost"] == 0.0):
        return False, None, "tour no valido"
    assign = tour_to_assignment(inst, tour)
    if assign is None:
        return False, None, "estructura no estandar (posible artefacto)"
    for j, cl in enumerate(inst.cnf.clauses):
        if not any(assign[abs(lit) - 1] == (lit > 0) for lit in cl):
            return False, assign, f"asignacion extraida no satisface c{j}"
    return True, assign, "SAT certificado"
