"""Re-certifica con el extractor robusto todos los tours de coste 0 conocidos."""
import numpy as np, time
from crypto_cnf import make_instance
from sat2tsp import reduce_cnf_to_tsp, certify_tour, check_tour_zero_cost
from certify_robust import certify_robust
from omega import omega_q2_strict, tour_length, _nearest_neighbor_start_q2
from plateau_fast import deltas
import exp_ladder

print("== A) instancias pequenas: tour de coste 0 de omega_q2_strict ==", flush=True)
for it in exp_ladder.small_instances():
    inst = reduce_cnf_to_tsp(it["cnf"], name=it["name"])
    t0=time.time(); tour = omega_q2_strict(inst.D); dt=time.time()-t0
    c = tour_length(inst.D, tour)
    if c == 0.0:
        ok1,_,m1 = certify_tour(inst, tour)
        ok2,ass,m2 = certify_robust(inst, tour, it["sat"])
        print(f"  {it['name']:<14} n={inst.n:<4} conste=0 t={dt:.1f}s | certify_tour={ok1} ({m1}) | "
              f"certify_robust={ok2} ({m2})", flush=True)

print("== B) cripto n=748: tour de coste 0 del descenso con laterales ==", flush=True)
def sideways_to_zero(D, tour, time_cap=420.0, seed=0):
    import random
    rng = random.Random(seed); D=np.asarray(D,float); t=np.array(tour,int); n=len(t)
    idx=np.arange(n); t0=time.time(); moves=0
    while time.time()-t0 < time_cap:
        if D[t, np.roll(t,-1)].sum() == 0.0: break
        d = deltas(D, t)
        mask=np.ones_like(d,bool); mask[idx,idx]=False; mask[idx,(idx+1)%n]=False
        mask[(idx+1)%n, idx]=False; d=np.where(mask,d,np.inf)
        if d.min() < -1e-15:
            i,j = np.unravel_index(np.argmin(d), d.shape)
        else:
            cand=np.argwhere(d==0.0)
            if len(cand)==0: break
            i,j = cand[rng.randrange(len(cand))]
        if i>j: i,j=j,i
        t=np.concatenate([t[:i+1], t[i+1:j+1][::-1], t[j+1:]]); moves+=1
    return t.tolist(), float(D[t,np.roll(t,-1)].sum()), moves, time.time()-t0

d = make_instance(4,1,1,seed=1)
inst = reduce_cnf_to_tsp(d["cnf"])
start = _nearest_neighbor_start_q2(inst.D, 0)
tour, cost, moves, dt = sideways_to_zero(inst.D, start)
print(f"  n={inst.n} coste={cost:.0f} movs={moves} t={dt:.1f}s", flush=True)
if cost==0.0:
    ok1,_,m1 = certify_tour(inst, tour)
    ok2,ass,m2 = certify_robust(inst, tour)
    print(f"  certify_tour  = {ok1} ({m1})", flush=True)
    print(f"  certify_robust= {ok2} ({m2})", flush=True)
    if ass: print("  asignacion de fases:", {k:int(v) for k,v in sorted(ass.items())}, " k*=", d["kstar"], flush=True)
