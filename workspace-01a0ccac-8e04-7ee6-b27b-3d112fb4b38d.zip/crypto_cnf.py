"""
crypto_cnf.py -- Instancias CNF de tipo criptografico REDUCIDAS.

Red de sustitucion-permutacion (SPN) diminuta estilo PRESENT:
    ronda = XOR clave_de_ronda -> S-box de 4 bits por nibble -> permutacion (rot)
La tarea SAT es recuperacion de clave con k pares texto-plano/cifrado.

Codificacion CNF (correcta y compacta):
  * XOR de dos bits: 4 clausulas; XOR con constante: 2.
  * S-box: CNF por bit de salida con cubos primos del conjunto OFF (Quine-McCluskey
    sobre 4 variables), i.e. la relacion y = S(x) exacta y mucho mas corta que 240
    clausulas.
  * Clausulas unitarias para fijar la salida a los bits del criptograma.

SAT / UNSAT:
  * pares generados con clave k*  => SAT con testigo verificable (witness_assign).
  * se puede anadir un par generado con OTRA clave => normalmente UNSAT; se
    VERIFICA por fuerza bruta sobre el espacio de claves (bits <= 20).
"""
import random

# ---------------------------------------------------------------- S-box 4 bits
SBOX = [0xC, 5, 6, 0xB, 9, 0, 0xA, 0xD, 3, 0xE, 0xF, 8, 4, 7, 1, 2]
SBOX_INV = [0] * 16
for i, v in enumerate(SBOX):
    SBOX_INV[v] = i


# ---------------------------------------------------------------- CNF de la S-box
def _bit(x, i):
    return (x >> i) & 1


def _cubes_cover(target):
    """Cover greedy de `target` (subconjunto de 0..15) con cubos maximales.

    Cubo = (v, m) con puntos {x : x&m == v&m}; se devuelven los elegidos."""
    cands = []
    for m in range(16):
        for v in range(16):
            if (v & ~m) != 0:
                continue
            cube = [x for x in range(16) if (x & m) == (v & m)]
            if all(x in target for x in cube):
                cands.append((len(cube), v, m))
    cands.sort(reverse=True)
    uncovered = set(target)
    chosen = []
    for size, v, m in cands:
        cube = set(x for x in range(16) if (x & m) == (v & m))
        if cube & uncovered:
            chosen.append((v, m))
            uncovered -= cube
        if not uncovered:
            break
    return chosen


def _cube_positions(v, m):
    """Posiciones fijadas del cubo (v, m) con su valor."""
    return [(i, _bit(v, i)) for i in range(4) if (m >> i) & 1]


class CNFBuilder:
    def __init__(self):
        self.nvar = 0
        self.clauses = []

    def new_var(self):
        self.nvar += 1
        return self.nvar

    def new_vars(self, n):
        return [self.new_var() for _ in range(n)]

    def add_clause(self, lits):
        self.clauses.append(tuple(lits))

    def xor2(self, a, b, out):
        self.add_clause([-a, -b, -out]); self.add_clause([a, b, -out])
        self.add_clause([a, -b, out]);   self.add_clause([-a, b, out])
        return out

    def xor_const(self, a, bit, out):
        if bit:
            self.add_clause([a, out]); self.add_clause([-a, -out])
        else:
            self.add_clause([-a, out]); self.add_clause([a, -out])
        return out

    def sbox4(self, ins, outs):
        """Relacion y = SBOX(x) exacta.

        Para cada bit de salida j: los cubos que cubren el ON-set dan clausulas que
        fuerzan outs[j]=1 dentro del cubo; los del OFF-set fuerzan outs[j]=0."""
        def clause_for(v, m, extra):
            # negacion del cubo: (x_i != b_i) OR ... ; FALSE exactamente en el cubo
            lits = [(-ins[i] if b else ins[i]) for (i, b) in _cube_positions(v, m)]
            lits.append(extra)
            self.add_clause(lits)

        for j in range(4):
            f = lambda x, j=j: _bit(SBOX[x], j)
            on = set(x for x in range(16) if f(x) == 1)
            off = set(x for x in range(16) if f(x) == 0)
            for (v, m) in _cubes_cover(on):
                clause_for(v, m, outs[j])
            for (v, m) in _cubes_cover(off):
                clause_for(v, m, -outs[j])
        return outs


from sat2tsp import CNF

# ---------------------------------------------------------------- cifra
def _nibbles(x, bits):
    return [(x >> (4 * i)) & 0xF for i in range(bits // 4)]


def _unnibbles(ns):
    x = 0
    for i, v in enumerate(ns):
        x |= (v & 0xF) << (4 * i)
    return x


def _permute(x, bits):
    m = (1 << bits) - 1
    return ((x << 1) | (x >> (bits - 1))) & m


def _round_key(key, r, bits):
    nb = bits // 4
    kn = _nibbles(key, bits)
    return _unnibbles([kn[(i + r) % nb] for i in range(nb)])


def encrypt_shift(x, key, bits, rounds):
    for r in range(rounds):
        x ^= _round_key(key, r, bits)
        x = _unnibbles([SBOX[v] for v in _nibbles(x, bits)])
        x = _permute(x, bits)
    return x


def brute_key_search_shift(pairs, bits, rounds):
    return [k for k in range(1 << bits)
            if all(encrypt_shift(p, k, bits, rounds) == c for p, c in pairs)]


# ---------------------------------------------------------------- CNF del cifrado
def build_cnf(bits, rounds, pairs):
    """Devuelve (CNF, key_vars, layout). layout permite reconstruir el testigo."""
    nb = bits // 4
    b = CNFBuilder()
    key = b.new_vars(bits)
    rk_vars = []
    for r in range(rounds):
        rk = [None] * bits
        for i in range(nb):
            src = (i + r) % nb
            for j in range(4):
                rk[4 * i + j] = key[4 * src + j]
        rk_vars.append(rk)

    layout = []
    for (p, c) in pairs:
        cur = [bool(_bit(p, i)) for i in range(bits)]
        per_round = []
        for r in range(rounds):
            after = [None] * bits
            for i in range(bits):
                out = b.new_var()
                if isinstance(cur[i], bool):
                    b.xor_const(rk_vars[r][i], cur[i], out)
                else:
                    b.xor2(cur[i], rk_vars[r][i], out)
                after[i] = out
            sb = [None] * bits
            for n in range(nb):
                outs = b.new_vars(4)
                b.sbox4(after[4 * n:4 * n + 4], outs)
                sb[4 * n:4 * n + 4] = outs
            per_round.append((after, sb))
            cur = [sb[(i - 1) % bits] for i in range(bits)]
        # igualar la salida al criptograma
        for i in range(bits):
            bit = bool(_bit(c, i))
            if isinstance(cur[i], bool):
                if cur[i] != bit:                 # inconsistencia: par forzado
                    z = b.new_var()
                    b.add_clause([z]); b.add_clause([-z])
            else:
                b.add_clause([cur[i]] if bit else [-cur[i]])
        layout.append(per_round)
    name = f"spn{bits}b_r{rounds}_p{len(pairs)}"
    return CNF(b.nvar, b.clauses, name=name), key, layout


def witness_assign(key_bits_vars, layout, key, plaintexts, bits, rounds):
    """Asignacion completa (dict indexado 0-based, como el de brute_sat) para la clave."""
    a = {}
    for i, v in enumerate(key_bits_vars):
        a[v - 1] = bool(_bit(key, i))
    for pr, pt in zip(layout, plaintexts):
        st = [_bit(pt, i) for i in range(bits)]
        for r, (after, sb) in enumerate(pr):
            rk = _round_key(key, r, bits)
            t = []
            for i in range(bits):
                val = st[i] ^ _bit(rk, i)
                a[after[i] - 1] = bool(val)
                t.append(val)
            for n in range(bits // 4):
                x = sum(t[4 * n + j] << j for j in range(4))
                y = SBOX[x]
                for j in range(4):
                    a[sb[4 * n + j] - 1] = bool(_bit(y, j))
            # permutacion
            prev = t
            st = [ _bit(_unnibbles([SBOX[sum(prev[4*n+j] << j for j in range(4))]
                                    for n in range(bits // 4)]), (i - 1) % bits)
                   for i in range(bits)]
        _ = st
    return a


# ---------------------------------------------------------------- instancias
def make_instance(bits, rounds, n_pairs, seed=0, inconsistent=False,
                  max_brute_bits=20, check=True):
    """-> dict(cnf, key, kstar, pairs, sat_esperado, layout, witness)."""
    rng = random.Random(seed * 100003 + bits * 97 + rounds * 13 + n_pairs)
    k_star = rng.randrange(1 << bits)
    pairs = []
    for _ in range(n_pairs):
        p = rng.randrange(1 << bits)
        pairs.append((p, encrypt_shift(p, k_star, bits, rounds)))
    sat_esp = True
    if inconsistent and n_pairs >= 2:
        k_bad = k_star
        while k_bad == k_star:
            k_bad = rng.randrange(1 << bits)
        p2 = rng.randrange(1 << bits)
        pairs.append((p2, encrypt_shift(p2, k_bad, bits, rounds)))
        sat_esp = None
    cnf, key, layout = build_cnf(bits, rounds, pairs)
    wit = (None if sat_esp is False else
           witness_assign(key, layout, k_star, [p for p, _ in pairs], bits, rounds))
    if check and sat_esp is None and bits <= max_brute_bits:
        sat_esp = len(brute_key_search_shift(pairs, bits, rounds)) > 0
    return dict(cnf=cnf, key=key, kstar=k_star, pairs=pairs, sat_esperado=sat_esp,
                layout=layout, witness=wit, spec=(bits, rounds, n_pairs, inconsistent))


# ---------------------------------------------------------------- escalera
LADDER = [   # (bits, rondas, n_pares, inconsistente)
    (4, 1, 1, False),
    (4, 2, 1, False),
    (4, 2, 2, False),
    (8, 1, 1, False),
    (8, 1, 2, False),
    (8, 2, 1, False),
    (8, 2, 2, False),
    (8, 2, 2, True),
    (4, 2, 2, True),
    (12, 1, 2, False),
    # (8, 3, 2, False)  -> n_TSP ~ 9429 y D float64 de ~0.7 GB: excede la memoria
    #                      del sandbox (1 GB); se deja fuera de la escalera por ahora.
]


def build_ladder():
    return [make_instance(bits, rounds, np, seed=i, inconsistent=inc)
            for i, (bits, rounds, np, inc) in enumerate(LADDER)]


if __name__ == "__main__":
    from sat2tsp import cnf_eval
    print(f"{'bits':>4} {'rond':>5} {'pares':>5} {'incons':>7} {'vars':>5} {'claus':>6} "
          f"{'SAT_esp':>8} {'witness_ok':>10}")
    for d in build_ladder():
        bits, rounds, npairs, incons = d["spec"]
        ok = cnf_eval(d["cnf"], d["witness"])
        print(f"{bits:>4} {rounds:>5} {npairs:>5} {str(incons):>7} {d['cnf'].nvars:>5} "
              f"{len(d['cnf'].clauses):>6} {str(d['sat_esperado']):>8} {str(ok):>10}")
