"""
tsp_contract.py -- Contraccion de nodos forzados (grado 2) en un TSPInstance 0/1.

Por que es valido:
  En un grafo con aristas de coste 0, un vertice v con exactamente dos aristas de
  coste 0 (vecinos a != b, ambas de coste 0) tiene que usar AMBAS en cualquier
  ciclo Hamiltoniano.  Por tanto v se puede contraer: se elimina v y se anade la
  arista (a,b) de coste 0.  La correspondencia es biyectiva
      ciclo Ham. de G  <->  ciclo Ham. de G'   (expandiendo a-v-b)
  de modo que el optimo (y la existencia de tour de coste 0) se conserva.

Uso:
    from tsp_contract import contract_degree2
    inst2, back = contract_degree2(inst)     # back: mapa nodo_contraido -> (a, v, b)
"""
from __future__ import annotations

import numpy as np

from sat2tsp import TSPInstance


def contract_degree2(inst: TSPInstance, max_rounds=100000):
    """Devuelve (TSPInstance contraida, historial) preservando el optimo."""
    n = inst.n
    D = np.array(inst.D, dtype=np.float64)
    alive = [True] * n
    nbrs = [set() for _ in range(n)]
    for (u, v) in inst.edges:
        if D[u, v] == 0.0:
            nbrs[u].add(v)
            nbrs[v].add(u)
    history = []
    changed = True
    rounds = 0
    while changed and rounds < max_rounds:
        changed = False
        rounds += 1
        for v in range(n):
            if not alive[v]:
                continue
            ns = [x for x in nbrs[v] if alive[x]]
            if len(ns) != 2:
                continue
            a, b = ns
            if a == b:
                continue
            # contraer: a - v - b  =>  a - b (coste 0), eliminar v
            alive[v] = False
            nbrs[a].discard(v)
            nbrs[b].discard(v)
            if b not in nbrs[a]:
                nbrs[a].add(b)
                nbrs[b].add(a)
            history.append((a, v, b))
            changed = True
    old = [i for i in range(n) if alive[i]]
    idx = {o: k for k, o in enumerate(old)}
    m = len(old)
    D2 = np.ones((m, m), dtype=np.float64)
    np.fill_diagonal(D2, 0.0)
    edges2 = []
    for a in range(n):
        if not alive[a]:
            continue
        for b in nbrs[a]:
            if alive[b] and a < b:
                edges2.append((idx[a], idx[b]))
                D2[idx[a], idx[b]] = D2[idx[b], idx[a]] = 0.0
    inst2 = TSPInstance(D=D2, edges=edges2, cnf=inst.cnf, gadgets=[], clause_node=[],
                        s=0, t=0, labels=[inst.labels[o] for o in old],
                        name=inst.name + "_contract", port_mode=inst.port_mode)
    return inst2, history


def expand_tour(inst, history, tour_contracted):
    """Re-expande un tour de la instancia contraida a la instancia original."""
    back = {}
    for (a, v, b) in history:
        back.setdefault((a, b), []).append(v)
        back.setdefault((b, a), []).append(v)
    labels = [inst.labels[t] for t in tour_contracted]         # etiquetas del tour
    pos = {lab: i for i, lab in enumerate(inst.labels)}
    out = []
    k = len(labels)
    for i in range(k):
        u, w = labels[i], labels[(i + 1) % k]
        out.append(u)
        for v in back.get((u, w), []):            # nodos contraidos entre u y w
            out.append(v)
    return out


if __name__ == "__main__":
    from crypto_cnf import make_instance
    from sat2tsp import reduce_cnf_to_tsp, brute_sat, CNF
    import random

    print("== cuantos nodos de grado 2 hay en los TSP de la reduccion ==")
    for spec in [(4, 1, 1, False), (8, 1, 1, False)]:
        bits, rounds, npairs, inc = spec
        d = make_instance(bits, rounds, npairs, seed=1, inconsistent=inc)
        inst = reduce_cnf_to_tsp(d["cnf"])
        inst2, hist = contract_degree2(inst)
        print(f"  spn{bits}b_r{rounds}_p{npairs}: n={inst.n} m={len(inst.edges)} -> "
              f"n={inst2.n} m={len(inst2.edges)}  (contraidos {len(hist)})")
    rng = random.Random(3)
    for t in range(3):
        nv, nc = rng.randint(2, 4), rng.randint(2, 5)
        cl = []
        for _ in range(nc):
            k = rng.randint(1, 3); lits = set()
            while len(lits) < k:
                v = rng.randint(1, nv); lits.add(v if rng.random() < .6 else -v)
            cl.append(tuple(lits))
        cnf = CNF(nv, cl, f"r{t}")
        inst = reduce_cnf_to_tsp(cnf)
        inst2, hist = contract_degree2(inst)
        print(f"  {cnf.name} (V={cnf.nvars},C={len(cnf.clauses)}): n={inst.n} m={len(inst.edges)} -> "
              f"n={inst2.n} m={len(inst2.edges)} (contraidos {len(hist)})")
