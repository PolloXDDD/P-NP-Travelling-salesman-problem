"""
export_results.py -- Convierte results.jsonl en resultados.csv y escalado.png.

Uso:  python3 export_results.py
"""
import csv
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

COLS = ["tag", "name", "n", "m", "sat", "solver", "coste", "t_heur", "umbral_ham",
        "certifica", "artefacto", "gap", "t_reduce", "motivo", "timeout_heur"]


def load(path="results.jsonl"):
    rows = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def main():
    rows = load()
    with open("resultados.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=COLS, extrasaction="ignore")
        w.writeheader()
        for r in sorted(rows, key=lambda d: (d["tag"], d["n"])):
            w.writerow(r)
    print(f"resultados.csv: {len(rows)} filas")

    fig, ax = plt.subplots(figsize=(8, 5))
    for tag, color, marker in [("plus", "#1f77b4", "o"), ("strict", "#d62728", "s")]:
        pts = sorted([(r["n"], r["coste"]) for r in rows
                      if r["tag"].endswith(tag) and r.get("coste") is not None])
        if pts:
            xs, ys = zip(*pts)
            ax.plot(xs, ys, marker=marker, color=color, label=f"omega_q2_{tag}",
                    lw=1.5, ms=6)
    ax.axhline(0.0, color="green", ls="--", lw=1.2, label="optimo certificado (SAT)")
    for r in rows:
        if r["tag"].endswith("plus") and r.get("coste"):
            ax.annotate(r["name"].replace("_i0", ""), (r["n"], r["coste"]),
                        fontsize=7, rotation=20, xytext=(2, 4),
                        textcoords="offset points")
    ax.set_xlabel("n (nodos del TSP)")
    ax.set_ylabel("coste del tour (gap, optimo=0)")
    ax.set_title("SAT->TSP: gap del solver vs tamano  (optimo = 0 en todas las SAT)")
    ax.grid(alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig("escalado.png", dpi=140)
    print("escalado.png escrito")


if __name__ == "__main__":
    main()
