"""
plateau_demo.py -- Ilustracion de la causa raiz del estancamiento.

Los operadores del solver del usuario (`_two_opt_once_q2`, `_relocate_once_q2`,
`_swap_once_q2`) aceptan SOLO mejoras estrictas (delta < -1e-15).  En un TSP
0/1 disperso (los de la reduccion SAT->TSP) el paisaje es casi plano: la mayoria
de movimientos tiene delta = 0, asi que el polisher se detiene en el primer
optimo local.

Aqui se compara:
  (a) descenso estricto (como el solver): best-improvement con delta < 0
  (b) descenso con movimientos laterales (delta <= 0) elegidos al azar
sobre las MISMAS instancias y con el mismo presupuesto de movimientos.

NO es un solver alternativo: es un diagnostico.
"""
from __future__ import annotations

import random
import time

import numpy as np

from sat2tsp import reduce_cnf_to_tsp, CNF, brute_sat
from omega import tour_length, _nearest_neighbor_start_q2


def best_2opt(D, tour, allow_sideways=False, rng=None, max_sideways=1):
    """Un barrido de 2-opt. Devuelve (tour, aplicado)."""
    n = len(tour)
    best_delta = 0.0
    best = []
    for i in range(n - 1):
        a, b = tour[i], tour[(i + 1) % n]
        for j in range(i + 2, n if i > 0 else n - 1):
            c, d = tour[j], tour[(j + 1) % n]
            delta = D[a, c] + D[b, d] - D[a, b] - D[c, d]
            if delta < best_delta - 1e-15:
                best_delta = float(delta)
                best = [(i + 1, j)]
            elif allow_sideways and abs(delta) < 1e-15:
                best.append((i + 1, j))
    if not best:
        return tour, False
    if best_delta < 0:
        l, r = best[0]
        return tour[:l] + tour[l:r + 1][::-1] + tour[r + 1:], True
    l, r = rng.choice(best)                      # movimiento lateral aleatorio
    return tour[:l] + tour[l:r + 1][::-1] + tour[r + 1:], True


def descend(D, tour, allow_sideways=False, max_moves=20000, rng=None):
    tour = tour[:]
    moves = 0
    while moves < max_moves:
        tour, ch = best_2opt(D, tour, allow_sideways, rng)
        if not ch:
            break
        moves += 1
    return tour, moves


def run(inst, label, seed=0, max_moves=4000):
    rng = random.Random(seed)
    start = _nearest_neighbor_start_q2(inst.D, 0)
    out = {}
    t0 = time.time()
    t_strict, m_strict = descend(inst.D, start, False, max_moves, rng)
    out["estricto"] = (tour_length(inst.D, t_strict), m_strict, time.time() - t0)
    t0 = time.time()
    t_side, m_side = descend(inst.D, start, True, max_moves, rng)
    out["lateral"] = (tour_length(inst.D, t_side), m_side, time.time() - t0)
    print(f"{label:<20} n={inst.n:<5} arranque={tour_length(inst.D,start):<6.0f} | "
          f"estricto -> {out['estricto'][0]:<6.0f} ({out['estricto'][1]} movs, {out['estricto'][2]:.1f}s) | "
          f"lateral -> {out['lateral'][0]:<6.0f} ({out['lateral'][1]} movs, {out['lateral'][2]:.1f}s)",
          flush=True)
    return out


if __name__ == "__main__":
    import exp_ladder
    insts = exp_ladder.small_instances()
    for it in insts:
        inst = reduce_cnf_to_tsp(it["cnf"], name=it["name"])
        run(inst, it["name"])
    # y la criptografica mas pequena
    from crypto_cnf import make_instance
    d = make_instance(4, 1, 1, seed=1)
    inst = reduce_cnf_to_tsp(d["cnf"], name="spn4b_r1_p1")
    run(inst, "spn4b_r1_p1", max_moves=4000)
