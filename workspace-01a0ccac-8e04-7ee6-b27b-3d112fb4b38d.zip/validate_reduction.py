"""
validate_reduction.py
=====================
Valida la reduccion CNF -> TSP 0/1 con oraculos independientes:
  * fuerza bruta SAT (2^nvars)
  * held_karp_exact (del propio omega.py del usuario, exacto)
  * DFS exacto de ciclo Hamiltoniano (sat2tsp.has_hamiltonian_cycle)
  * CP-SAT (ortools) como optimo exacto del TSP
  * extraccion de la asignacion desde un tour de coste 0 -> ¿satisface la CNF?
"""
import random, sys, time
import numpy as np

from sat2tsp import (CNF, reduce_cnf_to_tsp, brute_sat, cnf_eval,
                     has_hamiltonian_cycle, tsp_exact_cpsat, gadget_hamiltonian_path_count,
                     check_tour_zero_cost, tour_to_assignment)
import omega


def random_cnf(rng, nvars, nclauses, maxlen=3, allow_tauto=False):
    clauses = []
    for _ in range(nclauses):
        k = rng.randint(1, maxlen)
        cl = []
        for _ in range(k):
            v = rng.randint(1, nvars)
            s = rng.choice([1, -1])
            cl.append(s * v)
        clauses.append(tuple(cl))
    return CNF(nvars, clauses, name=f"rand-{nvars}v-{nclauses}c")


def test_gadget():
    print("== Test 1: estructura del gadget (rutas L->R) ==")
    ok = True
    for k in range(1, 8):
        c = gadget_hamiltonian_path_count(k)
        print(f"   k={k}: rutas Hamiltonianas L->R = {c}   {'OK' if c == 2 else 'FALLA'}")
        ok &= (c == 2)
    print("   (k=0 se maneja como arista L-R directa)")
    ok &= (gadget_hamiltonian_path_count(0) == 1)
    print("== Test 2: con detour en la arista de FASE A (VERDADERO) ==")
    for k in range(1, 7):
        for r in range(1, k + 1):
            c = gadget_hamiltonian_path_count(k, use_detour_slots=(r,))
            # con el nodo-detour colgado de la arista de FASE A solo sobrevive
            # el patron de FASE A (VERDADERO) -> 1 ruta
            if c != 1:
                print(f"   FALLA k={k} r={r}: {c} rutas (esperado 1)")
                ok = False
        print(f"   k={k}: detour en r=1..k -> 1 ruta (solo FASE A)   OK")
    print("== Test 2b: detour en la arista de FASE B (FALSO) ==")
    for k in range(1, 7):
        for r in range(1, k + 1):
            c = gadget_hamiltonian_path_count(k, use_detour_slots=(-r,))  # negativo = arista B
            if c != 1:
                print(f"   FALLA k={k} r={r}: {c} rutas (esperado 1)")
                ok = False
        print(f"   k={k}: detour(B) en r=1..k -> 1 ruta (solo FASE B)   OK")
    return ok


def check_instance(cnf, use_hk=True, use_cpsat=False, verbose=False):
    """Compara SAT con Hamiltonicidad/optimo del TSP reducido. Devuelve dict."""
    inst = reduce_cnf_to_tsp(cnf)
    res = dict(name=cnf.name, n=inst.n, m=inst.m)
    sat, a = brute_sat(cnf)
    res["sat"] = sat
    if inst.n <= 2:
        res["skip"] = True
        return res
    ham, tour = has_hamiltonian_cycle(inst.n, inst.edges)
    res["ham"] = ham
    if ham:
        info = check_tour_zero_cost(inst, tour)
        res["tour_ok"] = info
        if not (info["permutation"] and info["cost"] == 0.0):
            res["error"] = "tour DFS invalido"
        if info.get("assignment_extracted") and not info.get("assignment_satisfies_cnf"):
            res["error"] = "asignacion extraida NO satisface la CNF"
    if use_hk and inst.n <= 16:
        t0 = time.perf_counter()
        _, opt = omega.held_karp_exact(inst.D)
        res["hk_opt"] = opt
        res["hk_s"] = time.perf_counter() - t0
    if use_cpsat:
        t0 = time.perf_counter()
        opt, proven = tsp_exact_cpsat(inst.D, time_limit=20.0)
        res["cpsat_opt"] = opt
        res["cpsat_proven"] = proven
        res["cpsat_s"] = time.perf_counter() - t0
    return res


def test_random(trials=200, seed=12345, lmax=4, kmax=5, use_hk=True, verbose=False):
    print(f"== Test 3: {trials} CNFs aleatorias (vars<= {lmax}, clausulas<= {kmax}) ==")
    rng = random.Random(seed)
    bad = 0
    for it in range(trials):
        nv = rng.randint(1, lmax)
        nc = rng.randint(0, kmax)
        cnf = random_cnf(rng, nv, nc)
        res = check_instance(cnf, use_hk=use_hk)
        if res.get("skip"):
            continue
        sat, ham = res["sat"], res["ham"]
        consistent = (sat == bool(ham))
        if "hk_opt" in res:
            consistent &= ((res["hk_opt"] == 0) == sat)
        if "error" in res:
            consistent = False
        if not consistent:
            bad += 1
            print("   MISMATCH:", cnf.clauses, res)
        elif verbose:
            print("   ok", cnf.clauses, res)
    print(f"   -> {trials - bad}/{trials} consistentes  {'OK' if bad == 0 else 'FALLOS: %d' % bad}")
    return bad == 0


def test_edge_cases():
    print("== Test 4: casos limite ==")
    cases = {
        "vacia (0 vars, 0 clausulas)": CNF(0, []),
        "sin clausulas (3 vars)": CNF(3, []),
        "clausula vacia (UNSAT)": CNF(2, [()]),
        "tautologia (x v ~x)": CNF(2, [(1, -1), (2,)]),
        "literal duplicado (x v x)": CNF(2, [(1, 1), (-2,)]),
        "variables no usadas": CNF(5, [(2,), (-4,)]),
        "1 var, 1 clausula": CNF(1, [(1,)]),
        "1 var UNSAT": CNF(1, [(1,), (-1,)]),
    }
    ok = True
    for nm, cnf in cases.items():
        sat, _ = brute_sat(cnf)
        inst = reduce_cnf_to_tsp(cnf)
        if inst.n <= 2:
            ham = "n<=2 (tour trivial)"
            consistent = sat  # un tour de 2 nodos siempre existe
        else:
            h, tour = has_hamiltonian_cycle(inst.n, inst.edges)
            ham = h
            consistent = (sat == bool(h))
            if h:
                info = check_tour_zero_cost(inst, tour)
                consistent &= (info["cost"] == 0.0 and info.get("assignment_satisfies_cnf", False))
        flag = "OK" if consistent else "FALLA"
        ok &= consistent
        print(f"   {nm:34s} SAT={str(sat):5s} n_tsp={inst.n:3d} m={inst.m:3d} ham={ham}  {flag}")
    return ok


def test_larger(trials=40, seed=777):
    print(f"== Test 5: {trials} CNFs medianas (vars<= 9, clausulas<= 14) con CP-SAT/DFS ==")
    rng = random.Random(seed)
    bad = 0
    for it in range(trials):
        nv = rng.randint(4, 9)
        nc = rng.randint(4, 14)
        cnf = random_cnf(rng, nv, nc)
        res = check_instance(cnf, use_hk=False, use_cpsat=(it % 4 == 0))
        sat, ham = res["sat"], res["ham"]
        consistent = (sat == bool(ham))
        if "cpsat_opt" in res and res["cpsat_proven"]:
            consistent &= ((res["cpsat_opt"] == 0) == sat)
        if "error" in res:
            consistent = False
        if not consistent:
            bad += 1
            print("   MISMATCH:", cnf.clauses, res)
        else:
            print(f"   ok n_tsp={res['n']:4d} SAT={sat} ham={ham}"
                  + (f" cpsat={res['cpsat_opt']}" if "cpsat_opt" in res else ""))
    print(f"   -> {'OK' if bad == 0 else 'FALLOS: %d' % bad}")
    return bad == 0


if __name__ == "__main__":
    allok = True
    allok &= test_gadget()
    allok &= test_random(trials=int(sys.argv[1]) if len(sys.argv) > 1 else 150)
    allok &= test_edge_cases()
    allok &= test_larger(trials=int(sys.argv[2]) if len(sys.argv) > 2 else 24)
    print("\nRESULTADO GLOBAL:", "TODO OK" if allok else "HAY FALLOS")
    sys.exit(0 if allok else 1)
