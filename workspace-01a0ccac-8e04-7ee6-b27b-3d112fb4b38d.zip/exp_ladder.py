"""
exp_ladder.py -- Experimentos de escalado.

  python3 exp_ladder.py small    # CNFs aleatorias: curva de tamano (n_TSP 15..165)
  python3 exp_ladder.py crypto   # familia criptografica reducida (SPN), escalera

Escribe resultados incrementalmente en results.jsonl (una linea JSON por corrida),
de modo que el progreso no se pierde aunque el proceso se corte.
"""
import json
import random
import sys
import time

from sat2tsp import CNF, brute_sat, reduce_cnf_to_tsp
from bench_tsp_sat import run_one

RESULTS = "results.jsonl"


def emit(row, tag):
    row["tag"] = tag
    with open(RESULTS, "a") as f:
        f.write(json.dumps(row) + "\n")
    print(f"[{tag}] {json.dumps(row)}", flush=True)


def small_instances():
    """CNFs aleatorias, una por tramo de tamano TSP (nunca n>190)."""
    rng = random.Random(11)
    bins = [(12, 25), (25, 40), (40, 60), (60, 85), (85, 115), (115, 150), (150, 190)]
    chosen = {}
    tries = 0
    while len(chosen) < len(bins) and tries < 3000:
        tries += 1
        nv, nc = rng.randint(1, 7), rng.randint(1, 10)
        cl = []
        for _ in range(nc):
            k = rng.randint(1, min(3, 2 * nv))
            lits = set()
            while len(lits) < k:
                v = rng.randint(1, nv)
                lits.add(v if rng.random() < 0.6 else -v)
            cl.append(tuple(lits))
        cnf = CNF(nv, cl, "cand")
        sat, a = brute_sat(cnf)
        inst = reduce_cnf_to_tsp(cnf, name="probe")
        n = inst.n
        for b in bins:
            if b not in chosen and b[0] <= n <= b[1] and sat:
                cnf.name = f"rand_{b[0]}_{b[1]}"
                chosen[b] = dict(cnf=cnf, sat=sat, name=cnf.name, witness=a)
                break
    return [chosen[b] for b in bins if b in chosen]


def crypto_instances():
    from crypto_cnf import make_instance, LADDER
    out = []
    for i, (bits, rounds, np, inc) in enumerate(LADDER):
        d = make_instance(bits, rounds, np, seed=i, inconsistent=inc)
        out.append(dict(cnf=d["cnf"], sat=bool(d["sat_esperado"]),
                        name=f"spn{bits}b_r{rounds}_p{np}_i{int(inc)}",
                        witness=d["witness"]))
    return out


def main():
    what = sys.argv[1] if len(sys.argv) > 1 else "small"
    cap_strict = int(sys.argv[2]) if len(sys.argv) > 2 else 300
    if what == "small":
        insts = small_instances()
        for it in insts:
            for solver in ("plus", "strict"):
                emit(run_one(it["cnf"], it["sat"], it["name"], witness=it["witness"],
                             solver=solver, cap=cap_strict), f"small/{solver}")
    else:
        insts = crypto_instances()
        for it in insts:
            row = run_one(it["cnf"], it["sat"], it["name"], witness=it["witness"],
                          solver="plus", cap=cap_strict)
            emit(row, "crypto/plus")
            if row["n"] <= 1600:            # strict solo en las instancias asequibles
                emit(run_one(it["cnf"], it["sat"], it["name"], witness=it["witness"],
                             solver="strict", cap=1800), "crypto/strict")


if __name__ == "__main__":
    main()
