"""
bench_tsp_sat.py -- Banco de pruebas: CNF -> TSP -> solver del usuario (omega_q2*).

Verdad de referencia (sin necesidad de resolutor exacto de TSP):
  * SAT=True  y testigo/tour construido  ->  optimo = 0  (PROBADO: hay ciclo Ham.)
  * SAT=False (verificado)               ->  optimo >= 1 (tour de coste 0 seria un fallo
                                            de la reduccion; se certifica con certify_tour)
Asi, para SAT el gap es exacto (= coste del tour del heuristica) sin resolver el TSP.

Salidas: tabla por instancia con
  n, m, t_reduccion, coste_heur, t_heur, umbral_Ham (coste==0),
  cert (certificado SAT por la asignacion extraida), gap, artefacto.
"""
from __future__ import annotations

import json
import signal
import time

from sat2tsp import (reduce_cnf_to_tsp, assignment_to_tour, certify_tour,
                     check_tour_zero_cost, brute_sat)
from omega import omega_q2_strict, omega_q2_plus, omega_q2, tour_length


class Timeout(Exception):
    pass


def _alarm(sig, frm):
    raise Timeout()


def timed(fn, cap=None):
    """Ejecuta fn() con un tope de segundos (signal.alarm). Devuelve (res, t, ok)."""
    if cap:
        old = signal.signal(signal.SIGALRM, _alarm)
        signal.alarm(int(cap))
    t0 = time.time()
    try:
        res = fn()
        ok = True
    except Timeout:
        res, ok = None, False
    finally:
        if cap:
            signal.alarm(0)
            signal.signal(signal.SIGALRM, old)
    return res, time.time() - t0, ok


SOLVERS = {
    "strict": omega_q2_strict,
    "plus": omega_q2_plus,
    "q2_0.5": lambda D: omega_q2(D, beta=0.5),
}


def run_one(cnf, sat_true, name, witness=None, solver="strict", cap=None,
            port_mode="cracker", verbose=True):
    """Ejecuta el pipeline completo sobre una CNF. Devuelve dict con resultados."""
    row = dict(name=name, sat=sat_true, solver=solver, port_mode=port_mode)

    inst, t_red, _ = timed(lambda: reduce_cnf_to_tsp(cnf, name=name,
                                                     port_mode=port_mode), cap=cap)
    row.update(n=inst.n, m=len(inst.edges), t_reduce=round(t_red, 2))

    # --- camino constructivo: testigo -> tour -> certificado (optimo = 0) ---
    if witness is not None:
        tour, _, _ = timed(lambda: assignment_to_tour(inst, witness), cap=cap)
        if tour is not None:
            ok, _, motivo = certify_tour(inst, tour)
            row["cert_testigo"] = bool(ok)
            row["motivo_testigo"] = motivo
        else:
            row["cert_testigo"] = False
            row["motivo_testigo"] = "assignment_to_tour=None"

    # --- heuristica del usuario ---
    fn = SOLVERS[solver]
    tour_h, t_h, done = timed(lambda: fn(inst.D), cap=cap)
    row["t_heur"] = round(t_h, 2)
    row["timeout_heur"] = (not done)
    if not done:
        row.update(coste=None, certifica=None, motivo="timeout", artefacto=None, gap=None)
    else:
        cost = float(tour_length(inst.D, tour_h))
        ok, _, motivo = certify_tour(inst, tour_h)
        row.update(coste=cost, certifica=bool(ok), motivo=motivo)
        row["artefacto"] = bool(cost == 0.0 and not sat_true)
        row["umbral_ham"] = bool(cost == 0.0)
        if sat_true:
            row["gap"] = cost                      # optimo probado = 0
            row["gap_exacto"] = True
        else:
            row["gap"] = None if cost is None else "<= %.0f" % (cost - 1)
            row["gap_exacto"] = False
    if verbose:
        print(f"  {name:<26} n={row['n']:<5} m={row['m']:<5} SAT={str(sat_true):<5} "
              f"coste={row.get('coste')} t={row['t_heur']}s "
              f"umbral={'SI' if row.get('umbral_ham') else 'no'} "
              f"cert={row.get('certifica')} gap={row.get('gap')}", flush=True)
    return row


def run_suite(instances, solver="strict", cap=None, port_mode="cracker", title=""):
    """instances: lista de dicts con claves cnf, sat, name y (opcional) witness."""
    if title:
        print(f"== {title} (solver={solver}, cap={cap}s) ==", flush=True)
    rows = []
    for it in instances:
        rows.append(run_one(it["cnf"], it["sat"], it["name"], witness=it.get("witness"),
                            solver=solver, cap=cap, port_mode=port_mode))
    return rows


def summary(rows, title=""):
    done = [r for r in rows if r.get("coste") is not None]
    sat = [r for r in done if r["sat"]]
    unsat = [r for r in done if not r["sat"]]
    out = {
        "title": title,
        "n_inst": len(rows),
        "n_timeout": len(rows) - len(done),
        "SAT_alcanzan_umbral": sum(1 for r in sat if r.get("umbral_ham")),
        "SAT_total": len(sat),
        "UNSAT_artefactos": sum(1 for r in unsat if r.get("artefacto")),
        "UNSAT_total": len(unsat),
    }
    return out


def print_summary(s):
    print(f"  -> {s['title']}: umbral Ham en SAT {s['SAT_alcanzan_umbral']}/{s['SAT_total']} | "
          f"artefactos en UNSAT {s['UNSAT_artefactos']}/{s['UNSAT_total']} | "
          f"timeouts {s['n_timeout']}/{s['n_inst']}", flush=True)


if __name__ == "__main__":
    # demo rapida: 3 CNFs aleatorias pequenas
    import random
    from sat2tsp import CNF
    rng = random.Random(0)
    insts = []
    for t in range(3):
        nv, nc = rng.randint(2, 4), rng.randint(2, 5)
        cl = [tuple(rng.sample([s * v for v in range(1, nv + 1) for s in (1, -1)],
                               rng.randint(1, min(3, 2 * nv)))) for _ in range(nc)]
        sat, a = brute_sat(CNF(nv, cl, f"demo{t}"))
        insts.append(dict(cnf=CNF(nv, cl, f"demo{t}"), sat=sat, name=f"demo{t}",
                          witness=a if sat else None))
    rows = run_suite(insts, solver="strict", title="demo")
    print(json.dumps(summary(rows, "demo"), indent=1))
