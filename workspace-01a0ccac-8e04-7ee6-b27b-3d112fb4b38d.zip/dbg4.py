from sat2tsp import *
cnf = CNF(5, [(-3, 3), (-5, -5), (1,), (1, -5), (-5, 1), (5, 4), (5, 5), (-5, 4, -5), (-1,), (-2, -1), (4,)])
inst = reduce_cnf_to_tsp(cnf)
print("compacta:", inst.cnf.clauses, " n =", inst.n)
sat,_=brute_sat(inst.cnf); print("SAT:", sat)
h, tour = has_hamiltonian_cycle(inst.n, inst.edges)
print("ham:", h)
if h:
    n=inst.n
    used=set()
    for i in range(n):
        a,b=tour[i],tour[(i+1)%n]; used.add((min(a,b),max(a,b)))
    assign = tour_to_assignment(inst, tour)
    print("assign:", assign, "eval:", cnf_eval(inst.cnf, assign))
    print("tour:", [inst.labels[v] for v in tour])
    # por gadget: que arista de fila se usa en cada frontera
    for i,g in enumerate(inst.gadgets):
        k=len(g.T)-1   # ranuras reales
        print(f" gadget {i} (var {i+1}) k_real={k} slots={g.clause_of_slot}")
        for r in range(len(g.T)-1):
            top=(min(g.T[r],g.T[r+1]),max(g.T[r],g.T[r+1])) in used
            bot=(min(g.B[r],g.B[r+1]),max(g.B[r],g.B[r+1])) in used
            # puertos: nodos de clausula adyacentes a extremos
            print(f"   frontera {r+1}: top_arista={top} bot_arista={bot}")
        print(f"   entrada L-T0={(min(g.L,g.T[0]),max(g.L,g.T[0])) in used} L-B0={(min(g.L,g.B[0]),max(g.L,g.B[0])) in used}"
              f"  salida T-R={(min(g.T[-1],g.R),max(g.T[-1],g.R)) in used} B-R={(min(g.B[-1],g.R),max(g.B[-1],g.R)) in used}")
        # travesanos forzados?
        ok=all(((min(g.T[r],g.Rg[r]),max(g.T[r],g.Rg[r])) in used and (min(g.Rg[r],g.B[r]),max(g.Rg[r],g.B[r])) in used) for r in range(len(g.T)))
        print(f"   todos los travesanos usados: {ok}")
    # uso de puertos: para cada nodo de clausula, que vecinos tiene en el tour
    succ={tour[(i+1)%n]: tour[i] for i in range(n)}
    print(" clausulas:")
    for j,c in enumerate(inst.clause_node):
        print(f"   c{j} {inst.cnf.clauses[j]}: vecinos en tour = {inst.labels[succ[c]]} y {inst.labels[tour[(tour.index(c)+1)%n]]}")
