"""
enumerate_zero_cycles.py -- Enumera TODOS los ciclos Hamiltonianos de coste 0 de una
instancia pequena y clasifica cada uno:
   * certificable  : la asignacion de fases satisface la CNF  (=> SAT probado)
   * artefacto     : ciclo de coste 0 que NO da una asignacion satisfaciente
Si en una instancia UNSAT aparece cualquier ciclo de coste 0, es un artefacto.

Uso: python3 enumerate_zero_cycles.py            (casos fixture)
"""
import sys
from sat2tsp import CNF, reduce_cnf_to_tsp, brute_sat, tour_to_assignment
from certify_robust import certify_robust, extract_assignment_by_phase, _edge_used
from sat2tsp import cnf_eval


def zero_cycles(inst):
    """Genera todos los ciclos Hamiltonianos usando solo aristas de coste 0."""
    n = inst.n
    adj = [[] for _ in range(n)]
    for (u, v) in inst.edges:
        if inst.D[u, v] == 0.0:
            adj[u].append(v)
            adj[v].append(u)
    start = 0
    found = []

    def dfs(cur, visited, path):
        if len(path) == n:
            if start in adj[cur]:
                found.append(path[:])
            return
        for w in adj[cur]:
            if w not in visited:
                visited.add(w)
                path.append(w)
                dfs(w, visited, path)
                path.pop()
                visited.remove(w)

    dfs(start, {start}, [start])
    # deduplicar rotaciones/reflejos
    seen = set()
    out = []
    for p in found:
        key = min(tuple(p[i:] + p[:i]) for i in range(n))
        key = min(key, tuple(reversed(key)))
        if key not in seen:
            seen.add(key)
            out.append(list(key))
    return out


def classify(inst, cyc, sat_true):
    ok, ass, motivo = certify_robust(inst, cyc)
    std = tour_to_assignment(inst, cyc)
    if ok:
        return "certificable", ass, motivo
    return "artefacto", ass, f"std_extractor={'None' if std is None else 'ok'} | {motivo}"


def run(cnf, label, port_mode="cracker"):
    sat, a = brute_sat(cnf)
    inst = reduce_cnf_to_tsp(cnf, port_mode=port_mode)
    cyc = zero_cycles(inst)
    n_cert = 0
    print(f"\n[{label}] port={port_mode} n={inst.n} m={len(inst.edges)} SAT={sat} "
          f"| ciclos de coste 0 encontrados: {len(cyc)}", flush=True)
    for i, c in enumerate(cyc[:6]):
        kind, ass, motivo = classify(inst, c, sat)
        n_cert += (kind == "certificable")
        print(f"   ciclo {i}: {kind}  ({motivo})", flush=True)
    if len(cyc) > 6:
        for c in cyc[6:]:
            kind, ass, motivo = classify(inst, c, sat)
            n_cert += (kind == "certificable")
    total_cert = n_cert
    print(f"   resumen: {total_cert}/{len(cyc)} certificables, "
          f"{len(cyc)-total_cert} artefactos", flush=True)
    return sat, len(cyc), total_cert


if __name__ == "__main__":
    print("=" * 76)
    run(CNF(1, [(1,)], "1var-SAT"), "1 variable, 1 clausula (SAT)")
    run(CNF(1, [(1,), (-1,)], "1var-UNSAT"), "1 variable, clausulas contradictorias (UNSAT)")
    run(CNF(2, [(1, 2), (1, -2), (-1, 2)], "2var-SAT"), "2 variables (SAT)")
    run(CNF(2, [(1, 2), (1, -2), (-1, 2), (-1, -2)], "2var-UNSAT"), "2 variables (UNSAT)")
