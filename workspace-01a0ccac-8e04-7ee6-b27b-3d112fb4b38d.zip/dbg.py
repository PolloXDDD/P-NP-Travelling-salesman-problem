import numpy as np
from sat2tsp import CNF, reduce_cnf_to_tsp, brute_sat, has_hamiltonian_cycle, check_tour_zero_cost, tour_to_assignment, cnf_eval

def show(cnf):
    inst = reduce_cnf_to_tsp(cnf)
    sat,_ = brute_sat(cnf)
    h, tour = has_hamiltonian_cycle(inst.n, inst.edges)
    print("CNF:", cnf.clauses, "compacta:", inst.cnf.clauses, "SAT=",sat)
    print("  n=",inst.n,"m=",inst.m,"ham=",h)
    if h:
        print("  tour:", [inst.labels[v] for v in tour])
        info = check_tour_zero_cost(inst, tour)
        print("  info:", info)
        a = tour_to_assignment(inst, tour)
        print("  assign:", a)
    return inst, tour

print("--- caso 1 var 1 clausula ---")
show(CNF(1, [(1,)]))
print()
print("--- caso UNSAT 3 ---")
show(CNF(3, [(-3,), (-3,), (3,), (3,-2), (-1,2,2)]))
