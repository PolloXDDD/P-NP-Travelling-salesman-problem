from sat2tsp import *
import numpy as np

cnf = CNF(3, [(-3,), (2,2,3), (-1,-3,-2), (-1,3)])
inst = reduce_cnf_to_tsp(cnf)
print("CNF compacta:", inst.cnf.clauses, "  n =", inst.n)
sat, a = brute_sat(inst.cnf); print("SAT:", sat, a)
h, tour = has_hamiltonian_cycle(inst.n, inst.edges)
print("ciclo Hamiltoniano:", h)
t = [inst.labels[v] for v in tour]
print("tour:", t)
info = check_tour_zero_cost(inst, tour); print(info)
assign = tour_to_assignment(inst, tour)
print("assign:", assign)
print("eval:", cnf_eval(inst.cnf, assign))
print()
# analizar cada gadget: que aristas de fila usa y en que fase "parece" estar
n = inst.n
succ = {tour[i]: tour[(i+1)%n] for i in range(n)}
pred = {tour[(i+1)%n]: tour[i] for i in range(n)}
used = set()
for i in range(n):
    a2,b2 = tour[i], tour[(i+1)%n]; used.add((min(a2,b2),max(a2,b2)))
for i,g in enumerate(inst.gadgets):
    print(f"gadget {i} (k={len(g.T)}) L={inst.labels[g.L]} R={inst.labels[g.R]} slots={g.clause_of_slot}")
    print(f"   succ(L)={inst.labels[succ[g.L]]} pred(L)={inst.labels[pred[g.L]]}  succ(R)={inst.labels[succ[g.R]]} used L-T0: {(min(g.L,g.T[0]),max(g.L,g.T[0])) in used}  L-B0: {(min(g.L,g.B[0]),max(g.L,g.B[0])) in used}")
    for r in range(len(g.T)):
        T,B,Rg = g.T[r], g.B[r], g.Rg[r]
        def u(x): return inst.labels[x]
        print(f"   slot{r+1}: T={u(T)} succ={u(succ[T])}  B={u(B)} succ={u(succ[B])}  g={u(Rg)} succ={u(succ[Rg])}")
    for r in range(len(g.T)-1):
        print(f"   bound{r+1}: top {(min(g.T[r],g.T[r+1]),max(g.T[r],g.T[r+1])) in used}  bot {(min(g.B[r],g.B[r+1]),max(g.B[r],g.B[r+1])) in used}")
    print(f"   exit: top {(min(g.T[-1],g.R),max(g.T[-1],g.R)) in used} bot {(min(g.B[-1],g.R),max(g.B[-1],g.R)) in used}")
print()
for j,c in enumerate(inst.clause_node):
    predc, succc = pred[c], succ[c]
    print(f"clausula c{j} ({inst.cnf.clauses[j]}): entra desde {inst.labels[predc]}, sale a {inst.labels[succc]}")
