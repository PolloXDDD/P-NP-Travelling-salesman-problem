"""
plateau_fast.py -- Version vectorizada (numpy) del descenso 2-opt con movimientos
laterales, para comprobar el diagnostico tambien en las instancias grandes.

  - Movimiento estricto si existe (delta < -1e-15); si no, se toma UN movimiento
    lateral (delta == 0) al azar y se continua.
  - Se detiene cuando no hay ningun movimiento delta <= 0.

Uso:  python3 plateau_fast.py <n_max> <segundos_por_instancia>
"""
import random
import time

import numpy as np

from sat2tsp import reduce_cnf_to_tsp
from omega import tour_length, _nearest_neighbor_start_q2


def deltas(D, t):
    """Matriz de deltas 2-opt para el tour t (numpy)."""
    n = len(t)
    e = D[t, np.roll(t, -1)]                                  # coste de cada arista del tour
    T = D[np.ix_(t, t)]
    T1 = np.roll(np.roll(T, -1, axis=0), -1, axis=1)          # T1[i,j] = D[t_{i+1}, t_{j+1}]
    return T + T1 - e[:, None] - e[None, :]


def sideways_descent_np(D, tour, seed=0, max_moves=100000, time_cap=None):
    D = np.asarray(D, dtype=np.float64)
    rng = random.Random(seed)
    t = np.array(tour, dtype=int)
    n = len(t)
    idx = np.arange(n)
    t0 = time.time()
    moves = 0
    history = []
    while moves < max_moves:
        if time_cap and time.time() - t0 > time_cap:
            break
        d = deltas(D, t)
        # posiciones invalidas: i==j, j==i+1, i==j+1(==n-1 par), y el cierre i=0,j=n-1
        mask = np.ones_like(d, dtype=bool)
        mask[idx, idx] = False
        mask[idx, (idx + 1) % n] = False
        mask[(idx + 1) % n, idx] = False
        d = np.where(mask, d, np.inf)
        best = d.min()
        if best < -1e-15:
            i, j = np.unravel_index(np.argmin(d), d.shape)
        else:
            cand = np.argwhere(d == 0.0)
            if len(cand) == 0:
                break
            k = rng.randrange(len(cand))
            i, j = cand[k]
        # aplicar reverso del segmento (i+1 .. j) respetando el sentido circular
        if i > j:
            i, j = j, i
        t = np.concatenate([t[:i + 1], t[i + 1:j + 1][::-1], t[j + 1:]])
        moves += 1
        if moves % 200 == 0:
            history.append((moves, float(D[t, np.roll(t, -1)].sum())))
    cost = float(D[t, np.roll(t, -1)].sum())
    return t.tolist(), cost, moves, history, time.time() - t0


def strict_descent_np(D, tour, max_moves=100000):
    """Igual pero SIN laterales (criterio del solver del usuario)."""
    D = np.asarray(D, dtype=np.float64)
    t = np.array(tour, dtype=int)
    n = len(t)
    idx = np.arange(n)
    moves = 0
    while moves < max_moves:
        d = deltas(D, t)
        mask = np.ones_like(d, dtype=bool)
        mask[idx, idx] = False
        mask[idx, (idx + 1) % n] = False
        mask[(idx + 1) % n, idx] = False
        d = np.where(mask, d, np.inf)
        best = d.min()
        if best >= -1e-15:
            break
        i, j = np.unravel_index(np.argmin(d), d.shape)
        if i > j:
            i, j = j, i
        t = np.concatenate([t[:i + 1], t[i + 1:j + 1][::-1], t[j + 1:]])
        moves += 1
    return t.tolist(), float(D[t, np.roll(t, -1)].sum()), moves


if __name__ == "__main__":
    import sys
    n_max = int(sys.argv[1]) if len(sys.argv) > 1 else 200
    cap = float(sys.argv[2]) if len(sys.argv) > 2 else 120
    print(f"{'instancia':<18} {'n':>5} {'arranque':>8} {'estricto':>9} {'laterales':>10} "
          f"{'movs':>6} {'t(s)':>7}", flush=True)

    import exp_ladder
    for it in exp_ladder.small_instances():
        inst = reduce_cnf_to_tsp(it["cnf"], name=it["name"])
        if inst.n > n_max:
            continue
        st = _nearest_neighbor_start_q2(inst.D, 0)
        _, c_s, m_s = strict_descent_np(inst.D, st)
        _, c_l, m_l, _, dt = sideways_descent_np(inst.D, st, time_cap=cap)
        print(f"{it['name']:<18} {inst.n:>5} {tour_length(inst.D, st):>8.0f} {c_s:>9.0f} "
              f"{c_l:>10.0f} {m_l:>6} {dt:>7.1f}", flush=True)

    from crypto_cnf import make_instance
    for spec in [(4, 1, 1, False), (8, 1, 1, False)]:
        bits, rounds, npairs, inc = spec
        d = make_instance(bits, rounds, npairs, seed=1, inconsistent=inc)
        inst = reduce_cnf_to_tsp(d["cnf"], name=f"spn{bits}b_r{rounds}")
        st = _nearest_neighbor_start_q2(inst.D, 0)
        _, c_s, m_s = strict_descent_np(inst.D, st)
        _, c_l, m_l, _, dt = sideways_descent_np(inst.D, st, time_cap=cap)
        print(f"{f'spn{bits}b_r{rounds}':<18} {inst.n:>5} {tour_length(inst.D, st):>8.0f} {c_s:>9.0f} "
              f"{c_l:>10.0f} {m_l:>6} {dt:>7.1f}", flush=True)
