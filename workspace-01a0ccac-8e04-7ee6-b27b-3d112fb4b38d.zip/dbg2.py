from sat2tsp import *
def show(cnf):
    inst = reduce_cnf_to_tsp(cnf)
    sat,_ = brute_sat(cnf)
    h, tour = has_hamiltonian_cycle(inst.n, inst.edges)
    print("CNF:", cnf.clauses, "-> SAT =", sat, "| n_tsp =", inst.n, "m =", inst.m, "| cicloH =", h)
    if h:
        print("   tour:", [inst.labels[v] for v in tour][:40])
        print("   check:", check_tour_zero_cost(inst, tour))
for c in [CNF(1,[(1,)]), CNF(1,[(1,),(-1,)]), CNF(3,[(-3,),(-3,),(3,),(3,-2),(-1,2,2)]),
          CNF(2,[(1,),(-1,)]), CNF(2,[(1,),(-2,)])]:
    show(c)
print()
print("gadget puro con travesanos-nodo: k -> nº rutas L->R (tope 5)")
for k in range(1,9):
    print("  k=",k,"->",gadget_hamiltonian_path_count(k, limit=5))
print("gadget con detour FASE A (debe haber 1):")
for k in range(1,6):
    print("  k=",k,[gadget_hamiltonian_path_count(k, use_detour_slots=(r,), limit=3) for r in range(1,k+1)])
print("gadget SIN nodo de travesano (variante insegura):")
for k in range(1,5):
    print("  k=",k,"->",gadget_hamiltonian_path_count(k, rung_nodes=False, limit=5))
